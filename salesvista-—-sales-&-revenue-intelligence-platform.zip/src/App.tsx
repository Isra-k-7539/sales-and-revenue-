import React, { useState, useMemo } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar, NavTab } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { KPIGrid } from './components/KPIGrid';
import { FilterBar } from './components/FilterBar';
import { RevenueCharts } from './components/RevenueCharts';
import { TransactionTable } from './components/TransactionTable';
import { AIInsightsPanel } from './components/AIInsightsPanel';
import { RevenueTopology3D } from './components/RevenueTopology3D';
import { DataUploadModal } from './components/DataUploadModal';
import { ExportModal } from './components/ExportModal';
import { AuditLogsModal } from './components/AuditLogsModal';
import { DEFAULT_SALES_DATA } from './data/defaultSalesData';
import { DatasetSummary, FilterState, SalesRecord } from './types/dashboard';
import {
  calculateCategoryBreakdown,
  calculateKPIs,
  calculateRegionalPerformance,
  calculateRevenueTrends,
  calculateTopProducts,
  filterRecords,
} from './utils/analyticsEngine';
import {
  FileSpreadsheet,
  Layers,
  RotateCcw,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  Package,
  Globe,
  Database,
  CheckCircle2,
} from 'lucide-react';

function DashboardContent() {
  const { role, recordAuditLog } = useAuth();

  // Active dataset state
  const [datasetName, setDatasetName] = useState('Enterprise Demo Dataset (SaaS & Cloud)');
  const [records, setRecords] = useState<SalesRecord[]>(DEFAULT_SALES_DATA);
  const [datasetSummary, setDatasetSummary] = useState<DatasetSummary>({
    name: 'Enterprise Demo Dataset (SaaS & Cloud)',
    totalRows: DEFAULT_SALES_DATA.length,
    validRows: DEFAULT_SALES_DATA.length,
    missingValuesCount: 0,
    duplicatesCount: 0,
    detectedColumns: ['date', 'orderId', 'product', 'category', 'region', 'customer', 'channel', 'quantity', 'revenue', 'profit', 'cost'],
    columnMapping: {
      date: 'date',
      revenue: 'revenue',
      profit: 'profit',
      quantity: 'quantity',
      product: 'product',
      category: 'category',
      region: 'region',
      customer: 'customer',
      channel: 'channel',
      cost: 'cost',
      orderId: 'orderId',
    },
  });

  // Navigation tab
  const [activeTab, setActiveTab] = useState<NavTab>('overview');

  // Multi-dimensional filters
  const [filters, setFilters] = useState<FilterState>({
    startDate: '',
    endDate: '',
    selectedRegions: [],
    selectedCategories: [],
    selectedProducts: [],
    selectedChannels: [],
    searchTerm: '',
  });

  // Modals
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);

  // Available unique values for slicers
  const availableRegions = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.region))).filter(Boolean);
  }, [records]);

  const availableCategories = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.category))).filter(Boolean);
  }, [records]);

  const availableChannels = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.channel))).filter(Boolean);
  }, [records]);

  // Dynamically filtered records
  const filteredRecords = useMemo(() => {
    return filterRecords(records, filters);
  }, [records, filters]);

  // Derived metrics from filtered records
  const kpis = useMemo(() => calculateKPIs(filteredRecords), [filteredRecords]);
  const trendData = useMemo(() => calculateRevenueTrends(filteredRecords), [filteredRecords]);
  const categoryData = useMemo(() => calculateCategoryBreakdown(filteredRecords), [filteredRecords]);
  const topProducts = useMemo(() => calculateTopProducts(filteredRecords), [filteredRecords]);
  const regionalData = useMemo(() => calculateRegionalPerformance(filteredRecords), [filteredRecords]);

  // Handlers
  const handleApplyDataset = (newRecords: SalesRecord[], summary: DatasetSummary) => {
    setRecords(newRecords);
    setDatasetName(summary.name);
    setDatasetSummary(summary);
    // Reset filters for new dataset
    setFilters({
      startDate: '',
      endDate: '',
      selectedRegions: [],
      selectedCategories: [],
      selectedProducts: [],
      selectedChannels: [],
      searchTerm: '',
    });
  };

  const handleResetToDemo = () => {
    setRecords(DEFAULT_SALES_DATA);
    setDatasetName('Enterprise Demo Dataset (SaaS & Cloud)');
    setDatasetSummary({
      name: 'Enterprise Demo Dataset (SaaS & Cloud)',
      totalRows: DEFAULT_SALES_DATA.length,
      validRows: DEFAULT_SALES_DATA.length,
      missingValuesCount: 0,
      duplicatesCount: 0,
      detectedColumns: ['date', 'orderId', 'product', 'category', 'region', 'customer', 'channel', 'quantity', 'revenue', 'profit', 'cost'],
      columnMapping: {
        date: 'date',
        revenue: 'revenue',
        profit: 'profit',
        quantity: 'quantity',
        product: 'product',
        category: 'category',
        region: 'region',
        customer: 'customer',
        channel: 'channel',
        cost: 'cost',
        orderId: 'orderId',
      },
    });
    setFilters({
      startDate: '',
      endDate: '',
      selectedRegions: [],
      selectedCategories: [],
      selectedProducts: [],
      selectedChannels: [],
      searchTerm: '',
    });
    recordAuditLog('RESET_DEMO', 'Restored SalesVista Enterprise demo dataset');
  };

  const resetFiltersOnly = () => {
    setFilters({
      startDate: '',
      endDate: '',
      selectedRegions: [],
      selectedCategories: [],
      selectedProducts: [],
      selectedChannels: [],
      searchTerm: '',
    });
    recordAuditLog('FILTER_RESET', 'Cleared all active dashboard slicers and date ranges');
  };

  return (
    <div className="min-h-screen bg-[#0B1120] text-slate-100 flex flex-col md:flex-row font-sans selection:bg-indigo-500 selection:text-white">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          recordAuditLog('NAV_SWITCH', `Navigated to ${tab} view`);
        }}
        datasetName={datasetName}
        totalRows={records.length}
        onOpenUpload={() => setIsUploadOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <TopNav
          onOpenUpload={() => setIsUploadOpen(true)}
          onOpenExport={() => setIsExportOpen(true)}
        />

        <main className="p-4 sm:p-6 lg:p-8 space-y-6 flex-1 overflow-x-hidden">
          {/* Welcome / Context Banner */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                  {activeTab === 'overview' && 'Executive Sales & Revenue Intelligence'}
                  {activeTab === 'revenue' && 'Revenue Trajectory & Margin Dynamics'}
                  {activeTab === 'products' && 'Product Performance & Yield Analysis'}
                  {activeTab === 'regional' && 'Global Geographic Performance'}
                  {activeTab === 'topology3d' && '3D Revenue & Regional Topology'}
                  {activeTab === 'data-management' && 'Data Source & Column Mapping'}
                  {activeTab === 'audit-logs' && 'Security Audit Logs & Compliance'}
                </h1>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  v2.4
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Real-time multi-dimensional financial intelligence and automated algorithmic insights
              </p>
            </div>

            <div className="flex items-center gap-2">
              {datasetName !== 'Enterprise Demo Dataset (SaaS & Cloud)' && (
                <button
                  onClick={handleResetToDemo}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-800 border border-slate-700 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Restore Demo Dataset</span>
                </button>
              )}
            </div>
          </div>

          {/* Slicers & Filters Bar (Active across analytics views) */}
          {activeTab !== 'audit-logs' && activeTab !== 'data-management' && (
            <FilterBar
              filters={filters}
              setFilters={setFilters}
              availableRegions={availableRegions}
              availableCategories={availableCategories}
              availableChannels={availableChannels}
              onReset={resetFiltersOnly}
              filteredCount={filteredRecords.length}
              totalCount={records.length}
            />
          )}

          {/* TAB 1: OVERVIEW (Complete Dashboard) */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* 6 Executive KPI Metric Cards */}
              <KPIGrid kpis={kpis} />

              {/* Server-Side Gemini AI & Algorithmic Insights */}
              <AIInsightsPanel
                records={filteredRecords}
                kpis={kpis}
                regionalData={regionalData}
                categoryData={categoryData}
                topProducts={topProducts}
                onRecordAudit={recordAuditLog}
              />

              {/* Recharts Visualizations */}
              <RevenueCharts
                trendData={trendData}
                categoryData={categoryData}
                topProducts={topProducts}
                regionalData={regionalData}
                filteredRecords={filteredRecords}
              />

              {/* 3D Revenue Topology Teaser / Scene */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    <h3 className="text-sm font-semibold text-white">Spatial Financial Topology (3D)</h3>
                  </div>
                  <button
                    onClick={() => setActiveTab('topology3d')}
                    className="text-xs text-indigo-400 hover:text-indigo-300 underline font-medium cursor-pointer"
                  >
                    Expand to Full View
                  </button>
                </div>
                <RevenueTopology3D regionalData={regionalData} totalRevenue={kpis.totalRevenue} />
              </div>

              {/* Detailed Transaction Table */}
              <TransactionTable records={filteredRecords} onRecordAudit={recordAuditLog} />
            </div>
          )}

          {/* TAB 2: REVENUE TRENDS */}
          {activeTab === 'revenue' && (
            <div className="space-y-6">
              <KPIGrid kpis={kpis} />
              <RevenueCharts
                trendData={trendData}
                categoryData={categoryData}
                topProducts={topProducts}
                regionalData={regionalData}
                filteredRecords={filteredRecords}
              />
              <TransactionTable records={filteredRecords} onRecordAudit={recordAuditLog} />
            </div>
          )}

          {/* TAB 3: PRODUCT ANALYTICS */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              <KPIGrid kpis={kpis} />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl">
                  <h3 className="text-white font-semibold text-base mb-1 flex items-center gap-2">
                    <Package className="w-4 h-4 text-indigo-400" />
                    Product Margin & Volume Matrix
                  </h3>
                  <p className="text-xs text-slate-400 mb-4">Detailed ranking across all active product lines</p>

                  <div className="space-y-3">
                    {topProducts.map((p, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between"
                      >
                        <div>
                          <p className="text-xs font-semibold text-white">{p.name}</p>
                          <p className="text-[11px] text-slate-400">{p.category}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-mono font-bold text-emerald-400">
                            ${p.revenue.toLocaleString()}
                          </p>
                          <p className="text-[10px] text-slate-400">
                            {p.quantity} units • Margin: <strong className="text-sky-300">{p.margin}%</strong>
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl">
                  <h3 className="text-white font-semibold text-base mb-1">Category Contribution</h3>
                  <p className="text-xs text-slate-400 mb-4">Breakdown of billings by product group</p>
                  <div className="space-y-3">
                    {categoryData.map((c, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-200 font-medium">{c.name}</span>
                          <span className="text-slate-400 font-mono">
                            ${c.revenue.toLocaleString()} ({c.percentage}%)
                          </span>
                        </div>
                        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-indigo-500 h-2 rounded-full"
                            style={{ width: `${c.percentage}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <TransactionTable records={filteredRecords} onRecordAudit={recordAuditLog} />
            </div>
          )}

          {/* TAB 4: REGIONAL ANALYSIS */}
          {activeTab === 'regional' && (
            <div className="space-y-6">
              <KPIGrid kpis={kpis} />
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {regionalData.map((reg, idx) => (
                  <div
                    key={idx}
                    className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-4 shadow-xl"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-semibold text-white">{reg.region}</span>
                      <Globe className="w-4 h-4 text-sky-400" />
                    </div>
                    <p className="text-xl font-bold font-mono text-emerald-400">
                      ${reg.revenue.toLocaleString()}
                    </p>
                    <div className="mt-2 pt-2 border-t border-slate-800 flex justify-between text-[11px] text-slate-400">
                      <span>Orders: {reg.orders}</span>
                      <span>Margin: {reg.margin}%</span>
                    </div>
                  </div>
                ))}
              </div>

              <RevenueTopology3D regionalData={regionalData} totalRevenue={kpis.totalRevenue} />
              <TransactionTable records={filteredRecords} onRecordAudit={recordAuditLog} />
            </div>
          )}

          {/* TAB 5: 3D REVENUE TOPOLOGY */}
          {activeTab === 'topology3d' && (
            <div className="space-y-4">
              <div className="bg-[#1E293B]/60 border border-slate-700/60 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    Interactive 3D Revenue Space
                  </h3>
                  <p className="text-xs text-slate-400">
                    Spatial procedural models with studio PBR lighting, exponential damping, and collapsible dock
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('overview')}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:text-white"
                >
                  Back to Dashboard
                </button>
              </div>

              <RevenueTopology3D regionalData={regionalData} totalRevenue={kpis.totalRevenue} />
            </div>
          )}

          {/* TAB 6: DATA MANAGEMENT */}
          {activeTab === 'data-management' && (
            <div className="space-y-6">
              <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-6 shadow-xl space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-indigo-500/20 border border-indigo-500/30 rounded-xl">
                      <Database className="w-6 h-6 text-indigo-400" />
                    </div>
                    <div>
                      <h2 className="text-base font-semibold text-white">Dataset & Schema Intelligence</h2>
                      <p className="text-xs text-slate-400">
                        Automatic column inference, data hygiene, and custom mapping
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsUploadOpen(true)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md transition-colors cursor-pointer"
                  >
                    Upload New Dataset
                  </button>
                </div>

                {/* Dataset Summary Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-[#111827] border border-slate-800 rounded-xl p-4">
                    <span className="text-[11px] text-slate-400">Dataset Name</span>
                    <p className="text-sm font-semibold text-white truncate mt-1">{datasetSummary.name}</p>
                  </div>
                  <div className="bg-[#111827] border border-slate-800 rounded-xl p-4">
                    <span className="text-[11px] text-slate-400">Total Valid Rows</span>
                    <p className="text-sm font-mono font-semibold text-emerald-400 mt-1">
                      {datasetSummary.validRows}
                    </p>
                  </div>
                  <div className="bg-[#111827] border border-slate-800 rounded-xl p-4">
                    <span className="text-[11px] text-slate-400">Missing Values Detected</span>
                    <p className="text-sm font-mono font-semibold text-amber-400 mt-1">
                      {datasetSummary.missingValuesCount}
                    </p>
                  </div>
                  <div className="bg-[#111827] border border-slate-800 rounded-xl p-4">
                    <span className="text-[11px] text-slate-400">Duplicate Records</span>
                    <p className="text-sm font-mono font-semibold text-sky-400 mt-1">
                      {datasetSummary.duplicatesCount}
                    </p>
                  </div>
                </div>

                {/* Active Column Mapping */}
                <div>
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-3">
                    Active Column Schema Mapping
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {Object.entries(datasetSummary.columnMapping).map(([key, val]) => (
                      <div
                        key={key}
                        className="p-3 bg-[#111827] border border-slate-800 rounded-xl flex items-center justify-between text-xs"
                      >
                        <span className="text-slate-400 capitalize">{key}:</span>
                        <span className="text-indigo-300 font-mono font-semibold">
                          {val || '(Not mapped)'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <TransactionTable records={records} onRecordAudit={recordAuditLog} />
            </div>
          )}

          {/* TAB 7: AUDIT & COMPLIANCE */}
          {activeTab === 'audit-logs' && (
            <div className="space-y-6">
              <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-500/20 border border-indigo-500/30 rounded-xl">
                    <ShieldCheck className="w-6 h-6 text-indigo-400" />
                  </div>
                  <div>
                    <h2 className="text-base font-semibold text-white">
                      Enterprise Role-Based Access Control & Audit Log
                    </h2>
                    <p className="text-xs text-slate-400">
                      Append-only activity tracking, role policy enforcement, and compliance audit trail
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400">Current Role</span>
                    <p className="text-sm font-bold text-indigo-400 uppercase mt-1">{role}</p>
                    <p className="text-[11px] text-slate-400 mt-2">
                      Permissions: {role === 'admin' ? 'Full Read/Write/Export/Manage' : 'Restricted analytics'}
                    </p>
                  </div>
                  <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400">Database Engine</span>
                    <p className="text-sm font-semibold text-white mt-1">Google Cloud Firestore</p>
                    <p className="text-[11px] text-slate-400 mt-2">
                      ABAC security rules deployed & active
                    </p>
                  </div>
                  <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl">
                    <span className="text-xs text-slate-400">Total Activity Events</span>
                    <p className="text-sm font-mono font-semibold text-emerald-400 mt-1">
                      Logged in real-time
                    </p>
                    <button
                      onClick={() => setIsAuditModalOpen(true)}
                      className="mt-2 text-xs text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
                    >
                      Open Full Event Log Modal
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl">
                <h3 className="text-white font-semibold text-sm mb-3">Recent Security & Activity Trail</h3>
                <AuditLogsModal isOpen={true} onClose={() => {}} />
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Upload Dataset Modal */}
      <DataUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onApplyDataset={handleApplyDataset}
        onRecordAudit={recordAuditLog}
      />

      {/* Export Report Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        records={filteredRecords}
        kpis={kpis}
        datasetName={datasetName}
        onRecordAudit={recordAuditLog}
      />

      {/* Full Audit Logs Modal (if triggered outside tab) */}
      {isAuditModalOpen && (
        <AuditLogsModal isOpen={isAuditModalOpen} onClose={() => setIsAuditModalOpen(false)} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DashboardContent />
    </AuthProvider>
  );
}
