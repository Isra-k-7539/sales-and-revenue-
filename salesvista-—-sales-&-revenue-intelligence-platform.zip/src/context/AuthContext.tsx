import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import { doc, getDoc, setDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { auth, db, googleProvider, signInWithPopup, signOut } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { AuditLogItem, UserProfile, UserRole } from '../types/dashboard';

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  role: UserRole;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  switchDemoRole: (newRole: UserRole) => void;
  recordAuditLog: (action: string, details: string) => Promise<void>;
  auditLogs: AuditLogItem[];
  fetchAuditLogs: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole>('admin'); // Default role
  const [loading, setLoading] = useState(true);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Sync or fetch user profile from Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        try {
          const snap = await getDoc(userRef);
          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            setUserProfile(data);
            setRole(data.role || 'manager');
          } else {
            const newProfile: UserProfile = {
              userId: currentUser.uid,
              email: currentUser.email || 'user@example.com',
              displayName: currentUser.displayName || 'Authorized User',
              photoURL: currentUser.photoURL || '',
              role: currentUser.email === 'israrahmath262007@gmail.com' ? 'admin' : 'manager',
              createdAt: new Date().toISOString(),
              lastActiveAt: new Date().toISOString(),
            };
            await setDoc(userRef, newProfile);
            setUserProfile(newProfile);
            setRole(newProfile.role);
          }
        } catch (err) {
          console.warn('Could not sync user profile in Firestore:', err);
          // Fallback local profile
          setUserProfile({
            userId: currentUser.uid,
            email: currentUser.email || '',
            displayName: currentUser.displayName || 'User',
            role: 'admin',
            createdAt: new Date().toISOString(),
          });
        }
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error('Google sign in error:', err);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setUserProfile(null);
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  const switchDemoRole = (newRole: UserRole) => {
    setRole(newRole);
    if (userProfile) {
      setUserProfile({ ...userProfile, role: newRole });
    }
    recordAuditLog('ROLE_SWITCH', `Switched active RBAC role to ${newRole}`);
  };

  const recordAuditLog = async (action: string, details: string) => {
    const newLog: AuditLogItem = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      logId: `LOG-${Date.now()}`,
      userId: user?.uid || 'guest-session',
      userEmail: user?.email || 'guest@salesvista.internal',
      action,
      details,
      timestamp: new Date().toISOString(),
    };

    setAuditLogs((prev) => [newLog, ...prev.slice(0, 99)]);

    if (user) {
      try {
        await addDoc(collection(db, 'audit_logs'), {
          logId: newLog.logId,
          userId: newLog.userId,
          userEmail: newLog.userEmail,
          action: newLog.action,
          details: newLog.details,
          timestamp: newLog.timestamp,
        });
      } catch (err) {
        console.warn('Audit log write error:', err);
      }
    }
  };

  const fetchAuditLogs = async () => {
    // If guest, local memory logs are kept
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        role,
        loading,
        signInWithGoogle,
        logout,
        switchDemoRole,
        recordAuditLog,
        auditLogs,
        fetchAuditLogs,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
