import { ColumnMapping, DatasetSummary, SalesRecord } from '../types/dashboard';

/**
 * Normalizes a column name for fuzzy matching
 */
export function normalizeColName(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Automatically inspects dataset headers and infers the best column mapping
 */
export function detectColumnMapping(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {
    date: '',
    revenue: '',
    profit: '',
    quantity: '',
    product: '',
    category: '',
    region: '',
    customer: '',
    channel: '',
    cost: '',
    orderId: '',
  };

  const patterns: Record<keyof ColumnMapping, string[]> = {
    date: ['date', 'orderdate', 'transactiondate', 'sale_date', 'timestamp', 'created_at', 'time'],
    revenue: ['revenue', 'sales', 'totalsales', 'amount', 'totalamount', 'turnover', 'grosssales', 'total_revenue', 'price_total'],
    profit: ['profit', 'netprofit', 'earnings', 'netincome', 'margin_amount', 'gain'],
    quantity: ['quantity', 'qty', 'unitssold', 'units', 'volume', 'count', 'items'],
    product: ['product', 'productname', 'item', 'itemname', 'sku', 'product_name', 'model'],
    category: ['category', 'productcategory', 'department', 'vertical', 'segment_type', 'group'],
    region: ['region', 'territory', 'country', 'geography', 'state', 'location', 'market', 'area'],
    customer: ['customer', 'customername', 'client', 'account', 'clientname', 'buyer', 'company'],
    channel: ['channel', 'saleschannel', 'source', 'type', 'distribution'],
    cost: ['cost', 'cogs', 'expense', 'unitcost', 'totalcost'],
    orderId: ['orderid', 'transactionid', 'id', 'invoice', 'invoiceid', 'order_number'],
  };

  headers.forEach((header) => {
    const norm = normalizeColName(header);
    for (const [key, candidates] of Object.entries(patterns) as [keyof ColumnMapping, string[]][]) {
      if (!mapping[key]) {
        for (const candidate of candidates) {
          if (norm === candidate || norm.includes(candidate)) {
            mapping[key] = header;
            break;
          }
        }
      }
    }
  });

  return mapping;
}

/**
 * Validates and maps raw rows into strongly typed SalesRecords based on mapping
 */
export function mapRawDataToRecords(
  rows: Record<string, any>[],
  mapping: ColumnMapping
): { records: SalesRecord[]; summary: DatasetSummary } {
  let missingValuesCount = 0;
  const seenKeys = new Set<string>();
  let duplicatesCount = 0;
  const records: SalesRecord[] = [];

  rows.forEach((row, index) => {
    // Check missing values in critical mapped fields
    const reqFields: (keyof ColumnMapping)[] = ['date', 'revenue', 'product'];
    let hasMissing = false;
    for (const f of reqFields) {
      const col = mapping[f];
      if (col && (row[col] === undefined || row[col] === null || String(row[col]).trim() === '')) {
        hasMissing = true;
      }
    }
    if (hasMissing) missingValuesCount++;

    // Parse date safely
    let dateStr = '2024-01-01';
    if (mapping.date && row[mapping.date]) {
      const parsedDate = new Date(row[mapping.date]);
      if (!isNaN(parsedDate.getTime())) {
        dateStr = parsedDate.toISOString().split('T')[0];
      } else {
        dateStr = String(row[mapping.date]).substring(0, 10);
      }
    }

    // Parse numbers safely
    const parseNumber = (val: any): number => {
      if (typeof val === 'number') return isNaN(val) ? 0 : val;
      if (!val) return 0;
      const cleaned = String(val).replace(/[^0-9.-]/g, '');
      const parsed = parseFloat(cleaned);
      return isNaN(parsed) ? 0 : parsed;
    };

    const revenue = parseNumber(mapping.revenue ? row[mapping.revenue] : 0);
    let profit = parseNumber(mapping.profit ? row[mapping.profit] : 0);
    const quantity = Math.max(1, Math.round(parseNumber(mapping.quantity ? row[mapping.quantity] : 1)));
    const cost = parseNumber(mapping.cost ? row[mapping.cost] : 0);

    // If profit not provided but cost is, derive profit
    if (!mapping.profit && cost > 0 && revenue > 0) {
      profit = revenue - cost;
    } else if (!mapping.profit && revenue > 0) {
      profit = Math.round(revenue * 0.28 * 100) / 100; // default 28% estimation
    }

    const product = mapping.product && row[mapping.product] ? String(row[mapping.product]).trim() : 'Standard Product';
    const category = mapping.category && row[mapping.category] ? String(row[mapping.category]).trim() : 'General';
    const region = mapping.region && row[mapping.region] ? String(row[mapping.region]).trim() : 'Global';
    const customer = mapping.customer && row[mapping.customer] ? String(row[mapping.customer]).trim() : 'Enterprise Client';
    const channel = mapping.channel && row[mapping.channel] ? String(row[mapping.channel]).trim() : 'Direct';
    const orderId = mapping.orderId && row[mapping.orderId] ? String(row[mapping.orderId]).trim() : `ORD-${1000 + index}`;

    // Duplicate check
    const dedupKey = `${dateStr}_${product}_${customer}_${revenue}`;
    if (seenKeys.has(dedupKey)) {
      duplicatesCount++;
    } else {
      seenKeys.add(dedupKey);
    }

    records.push({
      id: `REC-${1000 + index}`,
      date: dateStr,
      orderId,
      product,
      category,
      region,
      customer,
      channel,
      quantity,
      revenue,
      profit,
      cost: cost > 0 ? cost : Math.max(0, revenue - profit),
    });
  });

  const headers = rows.length > 0 ? Object.keys(rows[0]) : [];

  return {
    records,
    summary: {
      name: 'Uploaded Dataset',
      totalRows: rows.length,
      validRows: records.length,
      missingValuesCount,
      duplicatesCount,
      detectedColumns: headers,
      columnMapping: mapping,
    },
  };
}
