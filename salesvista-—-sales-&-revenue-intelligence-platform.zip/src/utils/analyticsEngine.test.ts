import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateKPIs,
  calculateRevenueTrends,
  calculateCategoryBreakdown,
  calculateTopProducts,
  calculateRegionalPerformance,
  filterRecords,
  exportRecordsToCSV,
} from './analyticsEngine';
import { detectColumnMapping, mapRawDataToRecords } from './dataParser';
import { SalesRecord } from '../types/dashboard';

const sampleRecords: SalesRecord[] = [
  {
    id: '1',
    orderId: 'O-1',
    date: '2024-01-10',
    product: 'Product A',
    category: 'Software',
    region: 'North America',
    customer: 'Acme Corp',
    channel: 'Direct',
    quantity: 10,
    revenue: 1000,
    profit: 300,
    cost: 700,
  },
  {
    id: '2',
    orderId: 'O-2',
    date: '2024-01-20',
    product: 'Product B',
    category: 'Hardware',
    region: 'EMEA',
    customer: 'Beta LLC',
    channel: 'Partner',
    quantity: 5,
    revenue: 500,
    profit: 100,
    cost: 400,
  },
  {
    id: '3',
    orderId: 'O-3',
    date: '2024-02-15',
    product: 'Product A',
    category: 'Software',
    region: 'APAC',
    customer: 'Gamma Co',
    channel: 'Direct',
    quantity: 20,
    revenue: 2000,
    profit: 700,
    cost: 1300,
  },
];

test('calculateKPIs sums metrics accurately', () => {
  const kpis = calculateKPIs(sampleRecords);
  assert.equal(kpis.totalRevenue, 3500);
  assert.equal(kpis.totalProfit, 1100);
  assert.equal(kpis.totalOrders, 3);
  assert.equal(kpis.totalUnitsSold, 35);
  // Margin = (1100 / 3500) * 100 = 31.4%
  assert.equal(kpis.profitMargin, 31.4);
  // AOV = 3500 / 3 = 1166.67
  assert.equal(kpis.averageOrderValue, 1166.67);
});

test('filterRecords applies multi-criteria filters correctly', () => {
  const filtered = filterRecords(sampleRecords, {
    startDate: '2024-01-01',
    endDate: '2024-01-31',
    selectedRegions: ['North America'],
    selectedCategories: [],
    selectedProducts: [],
    selectedChannels: [],
    searchTerm: '',
  });

  assert.equal(filtered.length, 1);
  assert.equal(filtered[0].customer, 'Acme Corp');
});

test('calculateCategoryBreakdown groups and ranks correctly', () => {
  const categories = calculateCategoryBreakdown(sampleRecords);
  assert.equal(categories.length, 2);
  assert.equal(categories[0].name, 'Software');
  assert.equal(categories[0].revenue, 3000);
  assert.equal(categories[1].name, 'Hardware');
  assert.equal(categories[1].revenue, 500);
});

test('detectColumnMapping fuzzy maps raw CSV headers', () => {
  const headers = ['Order_Date', 'Gross_Revenue', 'Net_Earnings', 'Qty', 'Item_Name', 'Department', 'Territory'];
  const mapping = detectColumnMapping(headers);

  assert.equal(mapping.date, 'Order_Date');
  assert.equal(mapping.revenue, 'Gross_Revenue');
  assert.equal(mapping.profit, 'Net_Earnings');
  assert.equal(mapping.quantity, 'Qty');
  assert.equal(mapping.product, 'Item_Name');
  assert.equal(mapping.category, 'Department');
  assert.equal(mapping.region, 'Territory');
});

test('mapRawDataToRecords handles fallback and missing values', () => {
  const rawRows = [
    { Order_Date: '2024-03-01', Gross_Revenue: '1,500.50', Net_Earnings: '450', Qty: '3', Item_Name: 'Cloud DB' },
    { Order_Date: '', Gross_Revenue: '2,000', Net_Earnings: '', Qty: '2', Item_Name: 'API Proxy' },
  ];
  const mapping = detectColumnMapping(Object.keys(rawRows[0]));
  const { records, summary } = mapRawDataToRecords(rawRows, mapping);

  assert.equal(records.length, 2);
  assert.equal(records[0].revenue, 1500.5);
  assert.equal(records[0].profit, 450);
  assert.equal(summary.totalRows, 2);
  assert.equal(summary.missingValuesCount >= 1, true);
});

test('exportRecordsToCSV formats data correctly', () => {
  const csv = exportRecordsToCSV(sampleRecords);
  assert.equal(csv.includes('Order ID,Date,Product'), true);
  assert.equal(csv.includes('Acme Corp'), true);
});
