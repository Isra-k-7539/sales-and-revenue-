import { SalesRecord } from '../types/dashboard';

export const DEFAULT_SALES_DATA: SalesRecord[] = [
  // Q1 2024 / Recent Months
  { id: 'TX-1001', orderId: 'ORD-9021', date: '2024-01-05', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'North America', customer: 'Apex Global Logistics', channel: 'Direct Sales', quantity: 12, revenue: 48000, profit: 14400, cost: 33600 },
  { id: 'TX-1002', orderId: 'ORD-9022', date: '2024-01-08', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'APAC', customer: 'Tokai Precision Ltd', channel: 'Partner', quantity: 25, revenue: 87500, profit: 35000, cost: 52500 },
  { id: 'TX-1003', orderId: 'ORD-9023', date: '2024-01-12', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'EMEA', customer: 'Nordic Fintech AB', channel: 'Online', quantity: 5, revenue: 15000, profit: 4500, cost: 10500 },
  { id: 'TX-1004', orderId: 'ORD-9024', date: '2024-01-17', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'North America', customer: 'Vanguard Health Systems', channel: 'Direct Sales', quantity: 30, revenue: 60000, profit: 21000, cost: 39000 },
  { id: 'TX-1005', orderId: 'ORD-9025', date: '2024-01-22', product: 'Cloud Migration Advisory', category: 'Professional Services', region: 'EMEA', customer: 'Helios Media Group', channel: 'Enterprise RFP', quantity: 2, revenue: 38000, profit: 9500, cost: 28500 },
  { id: 'TX-1006', orderId: 'ORD-9026', date: '2024-01-26', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'North America', customer: 'Quantum Dynamics Inc', channel: 'Direct Sales', quantity: 18, revenue: 63000, profit: 25200, cost: 37800 },
  { id: 'TX-1007', orderId: 'ORD-9027', date: '2024-01-29', product: 'Zero Trust Identity Gate', category: 'Security & Compliance', region: 'LATAM', customer: 'Banco Sol Sao Paulo', channel: 'Partner', quantity: 10, revenue: 29000, profit: 8700, cost: 20300 },

  // February
  { id: 'TX-1008', orderId: 'ORD-9028', date: '2024-02-03', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'EMEA', customer: 'Stellar Aerospace UK', channel: 'Direct Sales', quantity: 45, revenue: 90000, profit: 31500, cost: 58500 },
  { id: 'TX-1009', orderId: 'ORD-9029', date: '2024-02-07', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'APAC', customer: 'SingaPay Pte Ltd', channel: 'Online', quantity: 14, revenue: 42000, profit: 12600, cost: 29400 },
  { id: 'TX-1010', orderId: 'ORD-9030', date: '2024-02-12', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'North America', customer: 'Meridian Capital Partners', channel: 'Direct Sales', quantity: 20, revenue: 80000, profit: 24000, cost: 56000 },
  { id: 'TX-1011', orderId: 'ORD-9031', date: '2024-02-16', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'EMEA', customer: 'Bavaria Automotive AG', channel: 'Enterprise RFP', quantity: 35, revenue: 122500, profit: 49000, cost: 73500 },
  { id: 'TX-1012', orderId: 'ORD-9032', date: '2024-02-21', product: 'Data Pipeline Accelerator', category: 'Cloud Infrastructure', region: 'North America', customer: 'Omni Retail Group', channel: 'Partner', quantity: 16, revenue: 35200, profit: 8800, cost: 26400 },
  { id: 'TX-1013', orderId: 'ORD-9033', date: '2024-02-25', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'LATAM', customer: 'PetroAndina Energy', channel: 'Partner', quantity: 15, revenue: 30000, profit: 10500, cost: 19500 },

  // March
  { id: 'TX-1014', orderId: 'ORD-9034', date: '2024-03-02', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'APAC', customer: 'Horizon Telco Sydney', channel: 'Direct Sales', quantity: 18, revenue: 72000, profit: 21600, cost: 50400 },
  { id: 'TX-1015', orderId: 'ORD-9035', date: '2024-03-06', product: 'AI Model Fine-Tuning Service', category: 'Professional Services', region: 'North America', customer: 'Cerebral Biosciences', channel: 'Enterprise RFP', quantity: 3, revenue: 54000, profit: 16200, cost: 37800 },
  { id: 'TX-1016', orderId: 'ORD-9036', date: '2024-03-11', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'North America', customer: 'Veritas Insurance Corp', channel: 'Direct Sales', quantity: 28, revenue: 98000, profit: 39200, cost: 58800 },
  { id: 'TX-1017', orderId: 'ORD-9037', date: '2024-03-15', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'LATAM', customer: 'Mercado Express Logistics', channel: 'Online', quantity: 8, revenue: 24000, profit: 7200, cost: 16800 },
  { id: 'TX-1018', orderId: 'ORD-9038', date: '2024-03-20', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'APAC', customer: 'Seoul Robotics Co', channel: 'Partner', quantity: 22, revenue: 44000, profit: 15400, cost: 28600 },
  { id: 'TX-1019', orderId: 'ORD-9039', date: '2024-03-25', product: 'Zero Trust Identity Gate', category: 'Security & Compliance', region: 'EMEA', customer: 'Parisian Luxury Retail SA', channel: 'Direct Sales', quantity: 14, revenue: 40600, profit: 12180, cost: 28420 },
  { id: 'TX-1020', orderId: 'ORD-9040', date: '2024-03-29', product: 'Cloud Migration Advisory', category: 'Professional Services', region: 'North America', customer: 'Beacon Health Systems', channel: 'Enterprise RFP', quantity: 1, revenue: 26000, profit: 7800, cost: 18200 },

  // April
  { id: 'TX-1021', orderId: 'ORD-9041', date: '2024-04-03', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'North America', customer: 'Delta Defense Systems', channel: 'Enterprise RFP', quantity: 40, revenue: 140000, profit: 56000, cost: 84000 },
  { id: 'TX-1022', orderId: 'ORD-9042', date: '2024-04-07', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'EMEA', customer: 'Zurich Risk Management', channel: 'Direct Sales', quantity: 24, revenue: 96000, profit: 28800, cost: 67200 },
  { id: 'TX-1023', orderId: 'ORD-9043', date: '2024-04-12', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'North America', customer: 'Sierra Nevada Logistics', channel: 'Online', quantity: 16, revenue: 32000, profit: 11200, cost: 20800 },
  { id: 'TX-1024', orderId: 'ORD-9044', date: '2024-04-18', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'APAC', customer: 'Nippon Semiconductor', channel: 'Partner', quantity: 18, revenue: 54000, profit: 16200, cost: 37800 },
  { id: 'TX-1025', orderId: 'ORD-9045', date: '2024-04-24', product: 'Zero Trust Identity Gate', category: 'Security & Compliance', region: 'North America', customer: 'Atlas Cloud Computing', channel: 'Direct Sales', quantity: 12, revenue: 34800, profit: 10440, cost: 24360 },

  // May
  { id: 'TX-1026', orderId: 'ORD-9046', date: '2024-05-02', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'APAC', customer: 'Bengaluru AI Labs', channel: 'Direct Sales', quantity: 30, revenue: 105000, profit: 42000, cost: 63000 },
  { id: 'TX-1027', orderId: 'ORD-9047', date: '2024-05-09', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'EMEA', customer: 'Iberia Telecom Solutions', channel: 'Partner', quantity: 26, revenue: 52000, profit: 18200, cost: 33800 },
  { id: 'TX-1028', orderId: 'ORD-9048', date: '2024-05-14', product: 'Data Pipeline Accelerator', category: 'Cloud Infrastructure', region: 'North America', customer: 'Chicago Mercantile Broker', channel: 'Online', quantity: 20, revenue: 44000, profit: 11000, cost: 33000 },
  { id: 'TX-1029', orderId: 'ORD-9049', date: '2024-05-20', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'LATAM', customer: 'Santiago Mining Corp', channel: 'Direct Sales', quantity: 15, revenue: 60000, profit: 18000, cost: 42000 },
  { id: 'TX-1030', orderId: 'ORD-9050', date: '2024-05-27', product: 'AI Model Fine-Tuning Service', category: 'Professional Services', region: 'EMEA', customer: 'Rotterdam Maritime Logistics', channel: 'Enterprise RFP', quantity: 2, revenue: 42000, profit: 12600, cost: 29400 },

  // June
  { id: 'TX-1031', orderId: 'ORD-9051', date: '2024-06-03', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'North America', customer: 'Boston Genomics', channel: 'Direct Sales', quantity: 36, revenue: 126000, profit: 50400, cost: 75600 },
  { id: 'TX-1032', orderId: 'ORD-9052', date: '2024-06-08', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'North America', customer: 'Keystone Energy Partners', channel: 'Direct Sales', quantity: 25, revenue: 100000, profit: 30000, cost: 70000 },
  { id: 'TX-1033', orderId: 'ORD-9053', date: '2024-06-15', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'EMEA', customer: 'Amsterdam Hosting NV', channel: 'Partner', quantity: 15, revenue: 45000, profit: 13500, cost: 31500 },
  { id: 'TX-1034', orderId: 'ORD-9054', date: '2024-06-21', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'APAC', customer: 'Sydney Harbour Ferries Ltd', channel: 'Online', quantity: 18, revenue: 36000, profit: 12600, cost: 23400 },
  { id: 'TX-1035', orderId: 'ORD-9055', date: '2024-06-28', product: 'Zero Trust Identity Gate', category: 'Security & Compliance', region: 'LATAM', customer: 'Bogota Digital Payments', channel: 'Partner', quantity: 11, revenue: 31900, profit: 9570, cost: 22330 },

  // July
  { id: 'TX-1036', orderId: 'ORD-9056', date: '2024-07-04', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'EMEA', customer: 'Scandinavia Power Grid', channel: 'Enterprise RFP', quantity: 42, revenue: 147000, profit: 58800, cost: 88200 },
  { id: 'TX-1037', orderId: 'ORD-9057', date: '2024-07-10', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'North America', customer: 'Pacific Rail Shipping', channel: 'Direct Sales', quantity: 32, revenue: 64000, profit: 22400, cost: 41600 },
  { id: 'TX-1038', orderId: 'ORD-9058', date: '2024-07-16', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'APAC', customer: 'Hong Kong Gateway Commerce', channel: 'Partner', quantity: 22, revenue: 88000, profit: 26400, cost: 61600 },
  { id: 'TX-1039', orderId: 'ORD-9059', date: '2024-07-23', product: 'Data Pipeline Accelerator', category: 'Cloud Infrastructure', region: 'EMEA', customer: 'Frankfurt Stock Exchange Rep', channel: 'Online', quantity: 18, revenue: 39600, profit: 9900, cost: 29700 },
  { id: 'TX-1040', orderId: 'ORD-9060', date: '2024-07-29', product: 'Cloud Migration Advisory', category: 'Professional Services', region: 'North America', customer: 'Austin Smart Mobility', channel: 'Enterprise RFP', quantity: 2, revenue: 46000, profit: 13800, cost: 32200 },

  // August
  { id: 'TX-1041', orderId: 'ORD-9061', date: '2024-08-03', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'North America', customer: 'Denver Health Network', channel: 'Direct Sales', quantity: 38, revenue: 133000, profit: 53200, cost: 79800 },
  { id: 'TX-1042', orderId: 'ORD-9062', date: '2024-08-09', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'North America', customer: 'Seattle E-Commerce Co', channel: 'Online', quantity: 24, revenue: 72000, profit: 21600, cost: 50400 },
  { id: 'TX-1043', orderId: 'ORD-9063', date: '2024-08-15', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'EMEA', customer: 'Milan Fashion Logistics', channel: 'Partner', quantity: 28, revenue: 56000, profit: 19600, cost: 36400 },
  { id: 'TX-1044', orderId: 'ORD-9064', date: '2024-08-21', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'LATAM', customer: 'Lima Agribusiness', channel: 'Direct Sales', quantity: 14, revenue: 56000, profit: 16800, cost: 39200 },
  { id: 'TX-1045', orderId: 'ORD-9065', date: '2024-08-27', product: 'Zero Trust Identity Gate', category: 'Security & Compliance', region: 'APAC', customer: 'Tokyo Advanced Materials', channel: 'Direct Sales', quantity: 20, revenue: 58000, profit: 17400, cost: 40600 },

  // September
  { id: 'TX-1046', orderId: 'ORD-9066', date: '2024-09-04', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'APAC', customer: 'Seoul Smart City Authority', channel: 'Enterprise RFP', quantity: 48, revenue: 168000, profit: 67200, cost: 100800 },
  { id: 'TX-1047', orderId: 'ORD-9067', date: '2024-09-11', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'North America', customer: 'Atlanta Media Works', channel: 'Online', quantity: 25, revenue: 50000, profit: 17500, cost: 32500 },
  { id: 'TX-1048', orderId: 'ORD-9068', date: '2024-09-17', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'EMEA', customer: 'Dublin Cloud Services Ltd', channel: 'Partner', quantity: 30, revenue: 120000, profit: 36000, cost: 84000 },
  { id: 'TX-1049', orderId: 'ORD-9069', date: '2024-09-22', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'North America', customer: 'Portland Microbrewery Network', channel: 'Online', quantity: 10, revenue: 30000, profit: 9000, cost: 21000 },
  { id: 'TX-1050', orderId: 'ORD-9070', date: '2024-09-28', product: 'AI Model Fine-Tuning Service', category: 'Professional Services', region: 'North America', customer: 'Silicon Bio Innovations', channel: 'Enterprise RFP', quantity: 4, revenue: 76000, profit: 22800, cost: 53200 },

  // October
  { id: 'TX-1051', orderId: 'ORD-9071', date: '2024-10-03', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'North America', customer: 'New York FinTech Group', channel: 'Direct Sales', quantity: 50, revenue: 175000, profit: 70000, cost: 105000 },
  { id: 'TX-1052', orderId: 'ORD-9072', date: '2024-10-09', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'North America', customer: 'Toronto Insurance Syndicate', channel: 'Direct Sales', quantity: 35, revenue: 140000, profit: 42000, cost: 98000 },
  { id: 'TX-1053', orderId: 'ORD-9073', date: '2024-10-15', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'EMEA', customer: 'Berlin Industrial Dynamics', channel: 'Partner', quantity: 34, revenue: 68000, profit: 23800, cost: 44200 },
  { id: 'TX-1054', orderId: 'ORD-9074', date: '2024-10-21', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'APAC', customer: 'Taipei Hardware Solutions', channel: 'Online', quantity: 22, revenue: 66000, profit: 19800, cost: 46200 },
  { id: 'TX-1055', orderId: 'ORD-9075', date: '2024-10-27', product: 'Zero Trust Identity Gate', category: 'Security & Compliance', region: 'LATAM', customer: 'Mexico City Banking Core', channel: 'Partner', quantity: 18, revenue: 52200, profit: 15660, cost: 36540 },

  // November
  { id: 'TX-1056', orderId: 'ORD-9076', date: '2024-11-04', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'EMEA', customer: 'London Financial Exchange', channel: 'Enterprise RFP', quantity: 45, revenue: 157500, profit: 63000, cost: 94500 },
  { id: 'TX-1057', orderId: 'ORD-9077', date: '2024-11-10', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'North America', customer: 'Minneapolis Grain Shipping', channel: 'Direct Sales', quantity: 38, revenue: 76000, profit: 26600, cost: 49400 },
  { id: 'TX-1058', orderId: 'ORD-9078', date: '2024-11-16', product: 'Data Pipeline Accelerator', category: 'Cloud Infrastructure', region: 'North America', customer: 'Phoenix Retail Chains', channel: 'Online', quantity: 25, revenue: 55000, profit: 13750, cost: 41250 },
  { id: 'TX-1059', orderId: 'ORD-9079', date: '2024-11-22', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'APAC', customer: 'Melbourne Port Authority', channel: 'Partner', quantity: 28, revenue: 112000, profit: 33600, cost: 78400 },
  { id: 'TX-1060', orderId: 'ORD-9080', date: '2024-11-28', product: 'Cloud Migration Advisory', category: 'Professional Services', region: 'EMEA', customer: 'Madrid Telecom SA', channel: 'Direct Sales', quantity: 3, revenue: 63000, profit: 18900, cost: 44100 },

  // December
  { id: 'TX-1061', orderId: 'ORD-9081', date: '2024-12-03', product: 'NeuralAnalytics Pro', category: 'AI Solutions', region: 'North America', customer: 'Silicon Valley Autonomous Inc', channel: 'Enterprise RFP', quantity: 55, revenue: 192500, profit: 77000, cost: 115500 },
  { id: 'TX-1062', orderId: 'ORD-9082', date: '2024-12-08', product: 'Cloud Sentinel Suite', category: 'Security & Compliance', region: 'North America', customer: 'Dallas Healthcare Alliance', channel: 'Direct Sales', quantity: 40, revenue: 160000, profit: 48000, cost: 112000 },
  { id: 'TX-1063', orderId: 'ORD-9083', date: '2024-12-14', product: 'Workflow Orchestrator', category: 'Enterprise SaaS', region: 'EMEA', customer: 'Geneva Private Banking Consort', channel: 'Direct Sales', quantity: 40, revenue: 80000, profit: 28000, cost: 52000 },
  { id: 'TX-1064', orderId: 'ORD-9084', date: '2024-12-19', product: 'Kubernetes Mesh Engine', category: 'Cloud Infrastructure', region: 'LATAM', customer: 'Buenos Aires Logistics S.A.', channel: 'Online', quantity: 16, revenue: 48000, profit: 14400, cost: 33600 },
  { id: 'TX-1065', orderId: 'ORD-9085', date: '2024-12-24', product: 'Zero Trust Identity Gate', category: 'Security & Compliance', region: 'APAC', customer: 'Singapore Data Center 1', channel: 'Partner', quantity: 24, revenue: 69600, profit: 20880, cost: 48720 },
  { id: 'TX-1066', orderId: 'ORD-9086', date: '2024-12-29', product: 'AI Model Fine-Tuning Service', category: 'Professional Services', region: 'North America', customer: 'Cambridge Cognitive Systems', channel: 'Enterprise RFP', quantity: 3, revenue: 58000, profit: 17400, cost: 40600 },
];
