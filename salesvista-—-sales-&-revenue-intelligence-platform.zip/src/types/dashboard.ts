export type UserRole = 'admin' | 'manager' | 'analyst' | 'viewer';

export interface UserProfile {
  userId: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  role: UserRole;
  createdAt: string;
  lastActiveAt?: string;
}

export interface SalesRecord {
  id: string;
  date: string; // ISO date YYYY-MM-DD
  orderId?: string;
  product: string;
  category: string;
  region: string;
  customer: string;
  channel: string;
  quantity: number;
  revenue: number;
  profit: number;
  cost?: number;
  discount?: number;
  [key: string]: any;
}

export interface ColumnMapping {
  date: string;
  revenue: string;
  profit: string;
  quantity: string;
  product: string;
  category: string;
  region: string;
  customer?: string;
  channel?: string;
  cost?: string;
  orderId?: string;
}

export interface DatasetSummary {
  name: string;
  totalRows: number;
  validRows: number;
  missingValuesCount: number;
  duplicatesCount: number;
  detectedColumns: string[];
  columnMapping: ColumnMapping;
}

export interface DashboardKPIs {
  totalRevenue: number;
  totalProfit: number;
  totalOrders: number;
  profitMargin: number; // percentage (e.g. 21.5)
  averageOrderValue: number;
  totalUnitsSold: number;
  revenueGrowthRate?: number;
}

export interface TrendDataPoint {
  date: string;
  label: string;
  revenue: number;
  profit: number;
  orders: number;
}

export interface CategoryDataPoint {
  name: string;
  revenue: number;
  profit: number;
  margin: number;
  percentage: number;
}

export interface ProductDataPoint {
  name: string;
  category: string;
  revenue: number;
  profit: number;
  quantity: number;
  margin: number;
}

export interface RegionDataPoint {
  region: string;
  revenue: number;
  profit: number;
  orders: number;
  margin: number;
}

export interface FilterState {
  startDate: string;
  endDate: string;
  selectedRegions: string[];
  selectedCategories: string[];
  selectedProducts: string[];
  selectedChannels: string[];
  searchTerm: string;
}

export interface AuditLogItem {
  id: string;
  logId: string;
  userId: string;
  userEmail: string;
  action: string;
  details: string;
  timestamp: string;
}
