import React, { useState, useMemo } from 'react';
import { SalesRecord } from '../types/dashboard';
import { exportRecordsToCSV } from '../utils/analyticsEngine';
import { Download, ChevronLeft, ChevronRight, ArrowUpDown, Search, FileText } from 'lucide-react';

interface TransactionTableProps {
  records: SalesRecord[];
  onRecordAudit: (action: string, details: string) => void;
}

type SortField = 'date' | 'revenue' | 'profit' | 'quantity' | 'product' | 'customer' | 'region';

export const TransactionTable: React.FC<TransactionTableProps> = ({ records, onRecordAudit }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortAsc, setSortAsc] = useState(false);
  const [tableSearch, setTableSearch] = useState('');

  // Local filter
  const filtered = useMemo(() => {
    if (!tableSearch) return records;
    const term = tableSearch.toLowerCase();
    return records.filter(
      (r) =>
        r.product.toLowerCase().includes(term) ||
        r.customer.toLowerCase().includes(term) ||
        r.region.toLowerCase().includes(term) ||
        r.category.toLowerCase().includes(term) ||
        (r.orderId && r.orderId.toLowerCase().includes(term))
    );
  }, [records, tableSearch]);

  // Sort
  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];
      if (typeof valA === 'string') {
        valA = valA.toLowerCase();
        valB = (valB as string).toLowerCase();
      }
      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  }, [filtered, sortField, sortAsc]);

  // Pagination
  const totalPages = Math.ceil(sorted.length / pageSize) || 1;
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sorted.slice(start, start + pageSize);
  }, [sorted, currentPage, pageSize]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false); // default descending for metrics
    }
  };

  const handleExportCSV = () => {
    const csvContent = exportRecordsToCSV(sorted);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `salesvista_transactions_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onRecordAudit('EXPORT_CSV', `Exported ${sorted.length} transaction records to CSV`);
  };

  return (
    <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl space-y-4">
      {/* Table Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-white font-semibold text-base flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-400" />
            Detailed Sales Transactions
          </h3>
          <p className="text-xs text-slate-400">
            Showing {sorted.length} verified records with ledger breakdown
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search table rows..."
              value={tableSearch}
              onChange={(e) => {
                setTableSearch(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-[#111827] border border-slate-700 text-white placeholder-slate-400 text-xs rounded-xl pl-8 pr-3 py-1.5 focus:outline-none focus:border-indigo-500 w-44"
            />
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors shadow-sm cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </button>
        </div>
      </div>

      {/* Table Surface */}
      <div className="overflow-x-auto rounded-xl border border-slate-700/60 bg-[#111827]">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-800/80 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-700">
            <tr>
              <th
                onClick={() => handleSort('date')}
                className="py-3 px-4 font-semibold cursor-pointer hover:text-white"
              >
                <div className="flex items-center gap-1">
                  Date <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th className="py-3 px-4 font-semibold">Order ID</th>
              <th
                onClick={() => handleSort('product')}
                className="py-3 px-4 font-semibold cursor-pointer hover:text-white"
              >
                <div className="flex items-center gap-1">
                  Product <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th className="py-3 px-4 font-semibold">Category</th>
              <th
                onClick={() => handleSort('region')}
                className="py-3 px-4 font-semibold cursor-pointer hover:text-white"
              >
                <div className="flex items-center gap-1">
                  Region <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th
                onClick={() => handleSort('customer')}
                className="py-3 px-4 font-semibold cursor-pointer hover:text-white"
              >
                <div className="flex items-center gap-1">
                  Customer <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th
                onClick={() => handleSort('quantity')}
                className="py-3 px-4 font-semibold text-right cursor-pointer hover:text-white"
              >
                <div className="flex items-center justify-end gap-1">
                  Qty <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th
                onClick={() => handleSort('revenue')}
                className="py-3 px-4 font-semibold text-right cursor-pointer hover:text-white"
              >
                <div className="flex items-center justify-end gap-1">
                  Revenue <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th
                onClick={() => handleSort('profit')}
                className="py-3 px-4 font-semibold text-right cursor-pointer hover:text-white"
              >
                <div className="flex items-center justify-end gap-1">
                  Profit <ArrowUpDown className="w-3 h-3 text-slate-500" />
                </div>
              </th>
              <th className="py-3 px-4 font-semibold text-right">Margin</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={10} className="py-8 text-center text-slate-500">
                  No matching transaction records found.
                </td>
              </tr>
            ) : (
              paginated.map((rec) => {
                const margin = rec.revenue > 0 ? (rec.profit / rec.revenue) * 100 : 0;
                return (
                  <tr key={rec.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-400">{rec.date}</td>
                    <td className="py-3 px-4 font-mono text-indigo-400">{rec.orderId || rec.id}</td>
                    <td className="py-3 px-4 font-medium text-white">{rec.product}</td>
                    <td className="py-3 px-4">
                      <span className="bg-slate-800 border border-slate-700 text-slate-300 px-2 py-0.5 rounded-md text-[11px]">
                        {rec.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-300">{rec.region}</td>
                    <td className="py-3 px-4 text-slate-200">{rec.customer}</td>
                    <td className="py-3 px-4 text-right font-mono">{rec.quantity}</td>
                    <td className="py-3 px-4 text-right font-mono font-semibold text-emerald-400">
                      ${rec.revenue.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-semibold text-sky-400">
                      ${rec.profit.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right font-mono">
                      <span
                        className={`inline-block px-1.5 py-0.5 rounded text-[11px] font-medium ${
                          margin >= 30
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/50'
                            : margin >= 15
                            ? 'bg-sky-950/80 text-sky-300 border border-sky-800/50'
                            : 'bg-amber-950/80 text-amber-300 border border-amber-800/50'
                        }`}
                      >
                        {margin.toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400 pt-2">
        <div className="flex items-center gap-2">
          <span>Rows per page:</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="bg-[#111827] border border-slate-700 text-white rounded-lg px-2 py-1 text-xs focus:outline-none focus:border-indigo-500"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
          </select>
          <span>
            Page {currentPage} of {totalPages}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded-lg border border-slate-700 bg-[#111827] text-slate-300 disabled:opacity-40 hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Previous Page"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded-lg border border-slate-700 bg-[#111827] text-slate-300 disabled:opacity-40 hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Next Page"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
