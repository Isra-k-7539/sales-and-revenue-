import React from 'react';
import { DashboardKPIs, SalesRecord } from '../types/dashboard';
import { exportRecordsToCSV } from '../utils/analyticsEngine';
import { Download, FileText, Printer, CheckCircle, X } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: SalesRecord[];
  kpis: DashboardKPIs;
  datasetName: string;
  onRecordAudit: (action: string, details: string) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  records,
  kpis,
  datasetName,
  onRecordAudit,
}) => {
  if (!isOpen) return null;

  const handleDownloadCSV = () => {
    const csvContent = exportRecordsToCSV(records);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${datasetName.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_export.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onRecordAudit('EXPORT_CSV', `Exported full dataset of ${records.length} records`);
    onClose();
  };

  const handlePrintPDF = () => {
    onRecordAudit('EXPORT_PDF', 'Initiated Executive PDF / Print snapshot');
    window.print();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 border border-indigo-500/30 rounded-xl">
              <Download className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-white font-semibold text-base">Export Business Intelligence</h2>
              <p className="text-xs text-slate-400">Download formatted datasets or generate PDF report</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close export modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Executive Metrics Overview Box */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-2">
            <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">
              Snapshot Included in Export
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-slate-400">Total Revenue:</span>
                <p className="text-white font-semibold font-mono">${kpis.totalRevenue.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-slate-400">Net Profit:</span>
                <p className="text-white font-semibold font-mono">${kpis.totalProfit.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-slate-400">Profit Margin:</span>
                <p className="text-purple-400 font-semibold font-mono">{kpis.profitMargin}%</p>
              </div>
              <div>
                <span className="text-slate-400">Total Transactions:</span>
                <p className="text-white font-semibold font-mono">{records.length} records</p>
              </div>
            </div>
          </div>

          {/* Export Options */}
          <div className="space-y-3">
            <button
              onClick={handleDownloadCSV}
              className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-700 bg-slate-800/60 hover:bg-slate-800 hover:border-slate-600 transition-all text-left cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400 group-hover:scale-105 transition-transform">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">Full Dataset Spreadsheet (.CSV)</h4>
                  <p className="text-[11px] text-slate-400">
                    Raw ledger transactions with formulas and numeric columns
                  </p>
                </div>
              </div>
              <Download className="w-4 h-4 text-slate-400 group-hover:text-emerald-400 transition-colors" />
            </button>

            <button
              onClick={handlePrintPDF}
              className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-700 bg-slate-800/60 hover:bg-slate-800 hover:border-slate-600 transition-all text-left cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-500/10 border border-indigo-500/30 rounded-lg text-indigo-400 group-hover:scale-105 transition-transform">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">Executive PDF Report / Print</h4>
                  <p className="text-[11px] text-slate-400">
                    Formatted executive briefing layout for board decks and reviews
                  </p>
                </div>
              </div>
              <Printer className="w-4 h-4 text-slate-400 group-hover:text-indigo-400 transition-colors" />
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-xl transition-colors cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
