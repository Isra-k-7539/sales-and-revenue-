import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RegionDataPoint } from '../types/dashboard';
import { Eye, Layers, RotateCcw, Sparkles, ChevronDown, ChevronUp } from 'lucide-react';

interface RevenueTopology3DProps {
  regionalData: RegionDataPoint[];
  totalRevenue: number;
}

export const RevenueTopology3D: React.FC<RevenueTopology3DProps> = ({ regionalData, totalRevenue }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [activePreset, setActivePreset] = useState<'perspective' | 'top' | 'isometric'>('perspective');
  const [wireframeMode, setWireframeMode] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);

  // References for render loop and controls
  const controlsRef = useRef<OrbitControls | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const towersGroupRef = useRef<THREE.Group | null>(null);
  const materialsRef = useRef<THREE.Material[]>([]);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // Detect software WebGL
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene & Fog
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x0b1120);
    scene.fog = new THREE.FogExp2(0x0b1120, 0.025);

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(12, 10, 16);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 4. Studio Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Studio Lighting Rig
    // Warm Key Directional Light
    const keyLight = new THREE.DirectionalLight(0xffecd2, 2.2);
    keyLight.position.set(14, 18, 12);
    keyLight.castShadow = !isSoftwareGl;
    if (keyLight.castShadow) {
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 40;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    scene.add(keyLight);

    // Cool Hemisphere Fill Light
    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0f172a, 1.2);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);

    // Subtle Cyan Accent Light
    const accentLight = new THREE.PointLight(0x6366f1, 2.5, 30);
    accentLight.position.set(-8, 6, -8);
    scene.add(accentLight);

    // 6. Ground & Procedural Grid Floor
    // Procedural Grid Texture on Canvas
    const gridCanvas = document.createElement('canvas');
    gridCanvas.width = 512;
    gridCanvas.height = 512;
    const ctx = gridCanvas.getContext('2d')!;
    ctx.fillStyle = '#0b1120';
    ctx.fillRect(0, 0, 512, 512);
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 2;
    for (let i = 0; i <= 512; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, 512);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(512, i);
      ctx.stroke();
    }
    // Subtle circular target rings
    ctx.strokeStyle = '#312e81';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(256, 256, 180, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(256, 256, 80, 0, Math.PI * 2);
    ctx.stroke();

    const gridTexture = new THREE.CanvasTexture(gridCanvas);
    gridTexture.wrapS = THREE.RepeatWrapping;
    gridTexture.wrapT = THREE.RepeatWrapping;
    gridTexture.repeat.set(4, 4);
    gridTexture.colorSpace = THREE.SRGBColorSpace;

    const floorGeo = new THREE.PlaneGeometry(36, 36);
    const floorMat = new THREE.MeshStandardMaterial({
      map: gridTexture,
      roughness: 0.6,
      metalness: 0.3,
    });
    materialsRef.current.push(floorMat);

    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = !isSoftwareGl;
    scene.add(floorMesh);

    // Soft Radial Contact Shadow Floor
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 256;
    shadowCanvas.height = 256;
    const sCtx = shadowCanvas.getContext('2d')!;
    const grad = sCtx.createRadialGradient(128, 128, 10, 128, 128, 120);
    grad.addColorStop(0, 'rgba(0,0,0,0.85)');
    grad.addColorStop(0.5, 'rgba(0,0,0,0.3)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, 256, 256);

    const shadowTex = new THREE.CanvasTexture(shadowCanvas);
    const shadowGeo = new THREE.PlaneGeometry(28, 28);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 0.6,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.y = 0.01;
    scene.add(shadowMesh);

    // 7. Composite Procedural 3-12 Part 3D Revenue Towers
    const towersGroup = new THREE.Group();
    scene.add(towersGroup);
    towersGroupRef.current = towersGroup;

    const regions = regionalData.length > 0 ? regionalData : [
      { region: 'North America', revenue: 450000, profit: 120000, orders: 45, margin: 26.6 },
      { region: 'EMEA', revenue: 320000, profit: 89000, orders: 38, margin: 27.8 },
      { region: 'APAC', revenue: 280000, profit: 75000, orders: 32, margin: 26.7 },
      { region: 'LATAM', revenue: 140000, profit: 38000, orders: 18, margin: 27.1 },
    ];

    const maxRev = Math.max(...regions.map((r) => r.revenue), 1);
    const palette = [
      { base: 0x6366f1, emissive: 0x4338ca, accent: 0xa5b4fc }, // Indigo
      { base: 0x22c55e, emissive: 0x15803d, accent: 0x86efac }, // Emerald
      { base: 0x38bdf8, emissive: 0x0284c7, accent: 0xbae6fd }, // Sky
      { base: 0xf59e0b, emissive: 0xb45309, accent: 0xfde68a }, // Amber
      { base: 0xec4899, emissive: 0xbe185d, accent: 0xfbcfe8 }, // Pink
    ];

    const radius = 6.5;
    regions.forEach((reg, idx) => {
      const angle = (idx / regions.length) * Math.PI * 2;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const heightScale = Math.max(1.8, (reg.revenue / maxRev) * 7.5);
      const colorSet = palette[idx % palette.length];

      // Procedural Tower Subject Group (6 distinct parts)
      const towerSubject = new THREE.Group();
      towerSubject.position.set(x, 0, z);

      // Part 1: Heavy Ground Plinth / Foundation (Octagonal Base)
      const baseGeo = new THREE.CylinderGeometry(1.6, 1.8, 0.4, 8);
      const baseMat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        metalness: 0.8,
        roughness: 0.25,
      });
      const baseMesh = new THREE.Mesh(baseGeo, baseMat);
      baseMesh.position.y = 0.2;
      baseMesh.castShadow = !isSoftwareGl;
      baseMesh.receiveShadow = !isSoftwareGl;
      towerSubject.add(baseMesh);

      // Part 2: Main Shaft (Vertical Glass/Steel Structure)
      const shaftGeo = new THREE.BoxGeometry(1.4, heightScale, 1.4);
      const shaftMat = new THREE.MeshPhysicalMaterial({
        color: colorSet.base,
        metalness: 0.85,
        roughness: 0.15,
        clearcoat: 0.8,
        clearcoatRoughness: 0.1,
      });
      materialsRef.current.push(shaftMat);
      const shaftMesh = new THREE.Mesh(shaftGeo, shaftMat);
      shaftMesh.position.y = 0.4 + heightScale / 2;
      shaftMesh.castShadow = !isSoftwareGl;
      shaftMesh.receiveShadow = !isSoftwareGl;
      towerSubject.add(shaftMesh);

      // Part 3: Glowing Energy Ring (Toroid Accent)
      const ringGeo = new THREE.TorusGeometry(1.0, 0.08, 12, 24);
      const ringMat = new THREE.MeshStandardMaterial({
        color: colorSet.accent,
        emissive: colorSet.emissive,
        emissiveIntensity: 2.5,
        roughness: 0.1,
        metalness: 0.9,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = Math.PI / 2;
      ringMesh.position.y = 0.4 + heightScale * 0.75;
      towerSubject.add(ringMesh);

      // Part 4: Beveled Upper Penthouse Tier
      const topGeo = new THREE.BoxGeometry(1.0, 0.6, 1.0);
      const topMat = new THREE.MeshStandardMaterial({
        color: 0x0f172a,
        metalness: 0.95,
        roughness: 0.1,
      });
      const topMesh = new THREE.Mesh(topGeo, topMat);
      topMesh.position.y = 0.4 + heightScale + 0.3;
      towerSubject.add(topMesh);

      // Part 5: Luminescent Spire / Antenna
      const spireGeo = new THREE.CylinderGeometry(0.04, 0.12, 1.2, 8);
      const spireMat = new THREE.MeshStandardMaterial({
        color: colorSet.accent,
        emissive: colorSet.accent,
        emissiveIntensity: 2.0,
      });
      const spireMesh = new THREE.Mesh(spireGeo, spireMat);
      spireMesh.position.y = 0.4 + heightScale + 0.6 + 0.6;
      towerSubject.add(spireMesh);

      // Part 6: Local Ground Contact Shadow Disk
      const discGeo = new THREE.CircleGeometry(2.0, 24);
      const discMat = new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        opacity: 0.7,
        depthWrite: false,
      });
      const discMesh = new THREE.Mesh(discGeo, discMat);
      discMesh.rotation.x = -Math.PI / 2;
      discMesh.position.y = 0.02;
      towerSubject.add(discMesh);

      towersGroup.add(towerSubject);
    });

    // Central Core Monument (Platform Hub)
    const hubGroup = new THREE.Group();
    const hubBaseGeo = new THREE.CylinderGeometry(2.5, 2.8, 0.5, 24);
    const hubBaseMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, roughness: 0.2 });
    const hubBase = new THREE.Mesh(hubBaseGeo, hubBaseMat);
    hubBase.position.y = 0.25;
    hubGroup.add(hubBase);

    // Core Crystal Sphere
    const crystalGeo = new THREE.IcosahedronGeometry(1.2, 2);
    const crystalMat = new THREE.MeshPhysicalMaterial({
      color: 0x6366f1,
      emissive: 0x312e81,
      emissiveIntensity: 1.5,
      metalness: 0.3,
      roughness: 0.1,
      transmission: isSoftwareGl ? 0 : 0.8,
      transparent: true,
      opacity: isSoftwareGl ? 0.6 : 1.0,
    });
    const crystalMesh = new THREE.Mesh(crystalGeo, crystalMat);
    crystalMesh.position.y = 1.8;
    hubGroup.add(crystalMesh);
    scene.add(hubGroup);

    // 8. Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controlsRef.current = controls;
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.05; // Keep above floor
    controls.minDistance = 6;
    controls.maxDistance = 30;

    // 9. Lossless render loop
    let frameId = 0;
    const clock = new THREE.Clock();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime() * speedMultiplier;

      // Gentle rotation of towers & central crystal
      if (towersGroupRef.current) {
        towersGroupRef.current.rotation.y = elapsed * 0.12;
      }
      crystalMesh.rotation.y = elapsed * 0.4;
      crystalMesh.rotation.x = Math.sin(elapsed * 0.5) * 0.15;

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    // Resize Handler
    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      renderer.dispose();
      materialsRef.current.forEach((m) => m.dispose());
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [regionalData, speedMultiplier]);

  // Camera presets
  const applyPreset = (preset: 'perspective' | 'top' | 'isometric') => {
    setActivePreset(preset);
    if (!cameraRef.current || !controlsRef.current) return;
    if (preset === 'perspective') {
      cameraRef.current.position.set(12, 10, 16);
    } else if (preset === 'top') {
      cameraRef.current.position.set(0.1, 24, 0.1);
    } else if (preset === 'isometric') {
      cameraRef.current.position.set(16, 14, 16);
    }
    controlsRef.current.target.set(0, 1, 0);
    controlsRef.current.update();
  };

  // Toggle wireframe mode
  const toggleWireframe = () => {
    const nextState = !wireframeMode;
    setWireframeMode(nextState);
    materialsRef.current.forEach((mat) => {
      mat.wireframe = nextState;
    });
  };

  return (
    <div className="relative w-full h-[520px] rounded-2xl overflow-hidden bg-[#0B1120] border border-slate-800 shadow-2xl">
      {/* Top Header Badge */}
      <div className="absolute top-4 left-5 z-10 pointer-events-none flex items-center space-x-3">
        <div className="p-2 bg-indigo-500/20 border border-indigo-500/40 rounded-xl backdrop-blur-md">
          <Layers className="w-5 h-5 text-indigo-400" />
        </div>
        <div>
          <h3 className="text-white font-semibold text-base tracking-wide flex items-center gap-2">
            3D Revenue & Regional Topology
            <span className="text-[11px] font-mono uppercase bg-indigo-950/80 text-indigo-300 px-2 py-0.5 rounded border border-indigo-700/50">
              WebGL Studio PBR
            </span>
          </h3>
          <p className="text-xs text-slate-400">
            Interactive territory elevation scaled by active revenue volume (${totalRevenue.toLocaleString()})
          </p>
        </div>
      </div>

      {/* 3D Canvas Mount Container */}
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Viewport-First Collapsible Bottom Control Dock */}
      <div
        className={`absolute bottom-4 left-1/2 -translate-x-1/2 z-20 transition-all duration-300 w-full max-w-[620px] px-4 ${
          isCollapsed ? 'translate-y-12' : 'translate-y-0'
        }`}
      >
        {/* Toggle Button */}
        <div className="flex justify-center mb-1">
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="flex items-center gap-1.5 px-3 py-1 bg-slate-900/90 text-slate-300 text-xs rounded-t-lg border border-b-0 border-slate-700/70 hover:text-white transition-colors cursor-pointer"
            aria-label="Toggle 3D controls"
          >
            {isCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-indigo-400" /> Show Controls
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5 text-indigo-400" /> Hide Controls
              </>
            )}
          </button>
        </div>

        {/* Floating Dock Surface */}
        <div className="bg-[#111827]/95 border border-slate-700/80 rounded-2xl p-3 shadow-2xl flex flex-wrap items-center justify-between gap-3">
          {/* Camera Angles */}
          <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl">
            <button
              onClick={() => applyPreset('perspective')}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
                activePreset === 'perspective'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Perspective
            </button>
            <button
              onClick={() => applyPreset('isometric')}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
                activePreset === 'isometric'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Isometric
            </button>
            <button
              onClick={() => applyPreset('top')}
              className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
                activePreset === 'top'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Top-Down
            </button>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={toggleWireframe}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors cursor-pointer ${
                wireframeMode
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                  : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Wireframe
            </button>

            <button
              onClick={() => setSpeedMultiplier((prev) => (prev === 1 ? 2 : prev === 2 ? 0.5 : 1))}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-indigo-400" />
              {speedMultiplier}x Orbit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
