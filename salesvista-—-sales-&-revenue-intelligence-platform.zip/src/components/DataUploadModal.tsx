import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { ColumnMapping, DatasetSummary, SalesRecord } from '../types/dashboard';
import { detectColumnMapping, mapRawDataToRecords } from '../utils/dataParser';
import { UploadCloud, CheckCircle2, AlertTriangle, X, FileSpreadsheet, ArrowRight, Settings2 } from 'lucide-react';

interface DataUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyDataset: (records: SalesRecord[], summary: DatasetSummary) => void;
  onRecordAudit: (action: string, details: string) => void;
}

export const DataUploadModal: React.FC<DataUploadModalProps> = ({
  isOpen,
  onClose,
  onApplyDataset,
  onRecordAudit,
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState('');
  const [rawRows, setRawRows] = useState<Record<string, any>[]>([]);
  const [detectedHeaders, setDetectedHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<ColumnMapping>({
    date: '',
    revenue: '',
    profit: '',
    quantity: '',
    product: '',
    category: '',
    region: '',
    customer: '',
    channel: '',
    cost: '',
    orderId: '',
  });
  const [showMappingStep, setShowMappingStep] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const processFile = async (file: File) => {
    setErrorMsg('');
    setFileName(file.name);

    try {
      const ext = file.name.split('.').pop()?.toLowerCase();
      if (ext === 'json') {
        const text = await file.text();
        const parsed = JSON.parse(text);
        const rows = Array.isArray(parsed) ? parsed : [parsed];
        if (rows.length === 0) throw new Error('JSON file is empty');
        setupParsedRows(rows);
      } else {
        // CSV or Excel (.xlsx, .xls)
        const arrayBuffer = await file.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rows: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
        if (rows.length === 0) throw new Error('Sheet contains no data rows');
        setupParsedRows(rows);
      }
    } catch (err: any) {
      console.error('File parsing error:', err);
      setErrorMsg(err.message || 'Failed to read file. Please verify CSV or Excel format.');
    }
  };

  const setupParsedRows = (rows: Record<string, any>[]) => {
    setRawRows(rows);
    const headers = Object.keys(rows[0] || {});
    setDetectedHeaders(headers);
    const autoMap = detectColumnMapping(headers);
    setMapping(autoMap);
    setShowMappingStep(true);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleConfirmAndApply = () => {
    if (!mapping.revenue && !mapping.product) {
      setErrorMsg('Please map at least Revenue and Product columns to proceed.');
      return;
    }

    const { records, summary } = mapRawDataToRecords(rawRows, mapping);
    summary.name = fileName || 'Custom Dataset';
    onApplyDataset(records, summary);
    onRecordAudit('DATASET_UPLOAD', `Uploaded ${fileName} with ${records.length} records`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#111827] border border-slate-700 w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 border border-indigo-500/30 rounded-xl">
              <FileSpreadsheet className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-white font-semibold text-base">Data Import & Schema Management</h2>
              <p className="text-xs text-slate-400">
                Upload CSV, Excel (.xlsx, .xls), or JSON with automatic column detection
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {!showMappingStep ? (
            /* Upload Drop Area */
            <div>
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all ${
                  dragActive
                    ? 'border-indigo-500 bg-indigo-500/10'
                    : 'border-slate-700 bg-slate-900/40 hover:border-slate-600'
                }`}
              >
                <div className="mx-auto w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center mb-4 text-indigo-400">
                  <UploadCloud className="w-8 h-8" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-1">
                  Drag and drop your sales dataset here
                </h3>
                <p className="text-xs text-slate-400 mb-4 max-w-sm mx-auto">
                  Supports Excel (.xlsx, .xls), CSV (.csv), and JSON (.json) with multi-column financial schemas
                </p>

                <label className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl cursor-pointer shadow-md transition-colors">
                  <span>Browse File</span>
                  <input
                    type="file"
                    accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, .json"
                    onChange={handleFileInput}
                    className="hidden"
                  />
                </label>
              </div>

              {errorMsg && (
                <div className="mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}
            </div>
          ) : (
            /* Column Mapping & Preview Step */
            <div className="space-y-6">
              {/* File details banner */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-800/80 border border-slate-700 rounded-xl text-xs">
                <div className="flex items-center gap-2 text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="font-medium text-white">{fileName}</span>
                  <span className="text-slate-500">•</span>
                  <span>{rawRows.length} rows detected</span>
                  <span className="text-slate-500">•</span>
                  <span>{detectedHeaders.length} columns</span>
                </div>
                <button
                  onClick={() => setShowMappingStep(false)}
                  className="text-xs text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
                >
                  Upload different file
                </button>
              </div>

              {/* Column Mapping Grid */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <Settings2 className="w-3.5 h-3.5 text-indigo-400" />
                  Verify Field Mapping
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { key: 'revenue', label: 'Revenue / Sales (*Required)' },
                    { key: 'profit', label: 'Net Profit' },
                    { key: 'product', label: 'Product / SKU (*Required)' },
                    { key: 'date', label: 'Transaction Date' },
                    { key: 'quantity', label: 'Quantity / Units' },
                    { key: 'category', label: 'Product Category' },
                    { key: 'region', label: 'Region / Territory' },
                    { key: 'customer', label: 'Customer / Client' },
                    { key: 'channel', label: 'Sales Channel' },
                  ].map((field) => (
                    <div key={field.key} className="bg-slate-900 border border-slate-700/80 rounded-xl p-2.5">
                      <label className="block text-[11px] font-medium text-slate-400 mb-1">
                        {field.label}
                      </label>
                      <select
                        value={mapping[field.key as keyof ColumnMapping] || ''}
                        onChange={(e) =>
                          setMapping((prev) => ({
                            ...prev,
                            [field.key]: e.target.value,
                          }))
                        }
                        className="w-full bg-[#111827] border border-slate-700 text-white text-xs rounded-lg px-2 py-1.5 focus:outline-none focus:border-indigo-500"
                      >
                        <option value="">-- None / Default --</option>
                        {detectedHeaders.map((hdr) => (
                          <option key={hdr} value={hdr}>
                            {hdr}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>

              {/* Data Preview Table */}
              <div>
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Dataset Sample Preview (First 5 Rows)
                </h4>
                <div className="overflow-x-auto rounded-xl border border-slate-800 bg-[#0B1120]">
                  <table className="w-full text-left text-[11px] text-slate-300">
                    <thead className="bg-slate-800 text-slate-400 border-b border-slate-700">
                      <tr>
                        {detectedHeaders.slice(0, 6).map((hdr) => (
                          <th key={hdr} className="py-2 px-3 font-semibold truncate">
                            {hdr}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80">
                      {rawRows.slice(0, 5).map((row, rIdx) => (
                        <tr key={rIdx}>
                          {detectedHeaders.slice(0, 6).map((hdr) => (
                            <td key={hdr} className="py-1.5 px-3 truncate max-w-[140px]">
                              {String(row[hdr] ?? '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        {showMappingStep && (
          <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmAndApply}
              className="flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg transition-colors cursor-pointer"
            >
              <span>Load Into Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
