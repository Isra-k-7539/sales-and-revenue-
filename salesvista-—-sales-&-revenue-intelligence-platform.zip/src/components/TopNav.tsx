import React from 'react';
import { useAuth } from '../context/AuthContext';
import { LogIn, LogOut, UploadCloud, Download, Bell, Shield, Sparkles } from 'lucide-react';

interface TopNavProps {
  onOpenUpload: () => void;
  onOpenExport: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({ onOpenUpload, onOpenExport }) => {
  const { user, role, signInWithGoogle, logout } = useAuth();

  return (
    <header className="h-16 bg-[#111827]/90 backdrop-blur-md border-b border-slate-800 px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Left side title / status */}
      <div className="flex items-center gap-3">
        <span className="text-xs text-slate-400 hidden sm:inline">
          Workspace / <strong className="text-slate-200">SalesVista Intelligence</strong>
        </span>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span>Real-time Analytics</span>
        </div>
      </div>

      {/* Right side actions */}
      <div className="flex items-center gap-3">
        {/* Role Badge */}
        <div className="hidden md:flex items-center gap-1.5 bg-slate-800/80 border border-slate-700 px-2.5 py-1 rounded-xl text-xs">
          <Shield className="w-3.5 h-3.5 text-indigo-400" />
          <span className="text-slate-400">Role:</span>
          <span className="text-indigo-300 font-semibold uppercase text-[11px]">{role}</span>
        </div>

        {/* Upload Button */}
        <button
          onClick={onOpenUpload}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors shadow-sm cursor-pointer"
        >
          <UploadCloud className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden sm:inline">Upload Dataset</span>
        </button>

        {/* Export Button */}
        <button
          onClick={onOpenExport}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Export Report</span>
        </button>

        {/* Google Firebase Sign In / Out */}
        {user ? (
          <button
            onClick={logout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer border border-transparent hover:border-rose-500/20"
            title="Sign out of Firebase Auth"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Sign Out</span>
          </button>
        ) : (
          <button
            onClick={signInWithGoogle}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white text-slate-900 hover:bg-slate-100 transition-colors shadow-sm cursor-pointer"
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Google Sign-In</span>
          </button>
        )}
      </div>
    </header>
  );
};
