import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ScatterChart,
  Scatter,
  ZAxis,
} from 'recharts';
import {
  CategoryDataPoint,
  ProductDataPoint,
  RegionDataPoint,
  SalesRecord,
  TrendDataPoint,
} from '../types/dashboard';
import { calculateWaterfallData } from '../utils/analyticsEngine';
import { TrendingUp, BarChart3, PieChart as PieIcon, Activity, Layers, DollarSign } from 'lucide-react';

interface RevenueChartsProps {
  trendData: TrendDataPoint[];
  categoryData: CategoryDataPoint[];
  topProducts: ProductDataPoint[];
  regionalData: RegionDataPoint[];
  filteredRecords: SalesRecord[];
}

const CATEGORY_COLORS = ['#6366F1', '#22C55E', '#38BDF8', '#F59E0B', '#EC4899', '#A855F7'];

export const RevenueCharts: React.FC<RevenueChartsProps> = ({
  trendData,
  categoryData,
  topProducts,
  regionalData,
  filteredRecords,
}) => {
  const [activeTab, setActiveTab] = useState<'trends' | 'waterfall' | 'scatter'>('trends');

  const waterfallData = calculateWaterfallData(filteredRecords);

  // Prepare scatter data: Sales vs Profit with quantity bubble
  const scatterData = filteredRecords.map((r) => ({
    x: r.revenue,
    y: r.profit,
    z: r.quantity,
    name: r.product,
    client: r.customer,
  }));

  const customTooltipStyle = {
    backgroundColor: '#0F172A',
    borderColor: '#334155',
    borderRadius: '12px',
    color: '#F8FAFC',
    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.5)',
    fontSize: '12px',
  };

  return (
    <div className="space-y-6">
      {/* Row 1: Main Trend / Growth Chart & Category Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 cols: Trend Chart / Waterfall / Scatter switchable */}
        <div className="lg:col-span-2 bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-white font-semibold text-base flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                Revenue & Profit Dynamics
              </h3>
              <p className="text-xs text-slate-400">Monthly trajectory, margins, and cost waterfall</p>
            </div>

            {/* Toggle buttons */}
            <div className="flex items-center gap-1 bg-[#111827] p-1 rounded-xl border border-slate-700">
              <button
                onClick={() => setActiveTab('trends')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'trends' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Trends
              </button>
              <button
                onClick={() => setActiveTab('waterfall')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'waterfall' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Waterfall
              </button>
              <button
                onClick={() => setActiveTab('scatter')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  activeTab === 'scatter' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Sales vs Profit
              </button>
            </div>
          </div>

          <div className="h-[320px] w-full">
            {activeTab === 'trends' && (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22C55E" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#22C55E" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#38BDF8" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#38BDF8" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                  <XAxis dataKey="label" stroke="#94A3B8" fontSize={11} tickLine={false} />
                  <YAxis
                    stroke="#94A3B8"
                    fontSize={11}
                    tickLine={false}
                    tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    contentStyle={customTooltipStyle}
                    formatter={(value: any, name: any) => [
                      `$${Number(value).toLocaleString()}`,
                      name === 'revenue' ? 'Revenue' : 'Net Profit',
                    ]}
                  />
                  <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    name="Revenue"
                    stroke="#22C55E"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#revenueGrad)"
                  />
                  <Area
                    type="monotone"
                    dataKey="profit"
                    name="Profit"
                    stroke="#38BDF8"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#profitGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}

            {activeTab === 'waterfall' && (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={waterfallData} margin={{ top: 20, right: 10, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                  <XAxis dataKey="step" stroke="#94A3B8" fontSize={11} tickLine={false} />
                  <YAxis
                    stroke="#94A3B8"
                    fontSize={11}
                    tickLine={false}
                    tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`}
                  />
                  <Tooltip
                    contentStyle={customTooltipStyle}
                    formatter={(value: any) => [`$${Math.abs(Number(value)).toLocaleString()}`, 'Value']}
                  />
                  <Bar
                    dataKey="value"
                    radius={[6, 6, 0, 0]}
                    fill="#6366F1"
                    name="Financial Stage"
                  >
                    {waterfallData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={entry.value >= 0 ? '#22C55E' : '#EF4444'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}

            {activeTab === 'scatter' && (
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 20, right: 20, bottom: 10, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    type="number"
                    dataKey="x"
                    name="Revenue"
                    stroke="#94A3B8"
                    fontSize={11}
                    tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                  />
                  <YAxis
                    type="number"
                    dataKey="y"
                    name="Profit"
                    stroke="#94A3B8"
                    fontSize={11}
                    tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                  />
                  <ZAxis type="number" dataKey="z" range={[50, 400]} name="Units" />
                  <Tooltip
                    contentStyle={customTooltipStyle}
                    formatter={(v: any, name: any) => [
                      name === 'Revenue' || name === 'Profit' ? `$${Number(v).toLocaleString()}` : v,
                      name,
                    ]}
                  />
                  <Scatter name="Transactions" data={scatterData} fill="#38BDF8" opacity={0.7} />
                </ScatterChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Right 1 col: Category Contribution Donut */}
        <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-white font-semibold text-base flex items-center gap-2 mb-1">
              <PieIcon className="w-4 h-4 text-purple-400" />
              Category Share
            </h3>
            <p className="text-xs text-slate-400">Revenue split and margin contribution</p>
          </div>

          <div className="h-[220px] w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="revenue"
                >
                  {categoryData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={CATEGORY_COLORS[index % CATEGORY_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={customTooltipStyle}
                  formatter={(value: any) => [`$${Number(value).toLocaleString()}`, 'Revenue']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Clean Legend List */}
          <div className="space-y-1.5 pt-2 border-t border-slate-700/60 max-h-[110px] overflow-y-auto">
            {categoryData.slice(0, 4).map((cat, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 truncate">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: CATEGORY_COLORS[idx % CATEGORY_COLORS.length] }}
                  />
                  <span className="text-slate-300 truncate">{cat.name}</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-slate-400">{cat.percentage}%</span>
                  <span className="text-white font-medium">${(cat.revenue / 1000).toFixed(0)}k</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Row 2: Top Performing Products & Regional Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products Horizontal / Vertical Bar Chart */}
        <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-semibold text-base flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-indigo-400" />
                Top-Performing Offerings
              </h3>
              <p className="text-xs text-slate-400">Ranked by gross sales volume and profit margin</p>
            </div>
          </div>

          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topProducts} layout="vertical" margin={{ top: 5, right: 20, left: 80, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
                <XAxis
                  type="number"
                  stroke="#94A3B8"
                  fontSize={11}
                  tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`}
                />
                <YAxis
                  dataKey="name"
                  type="category"
                  stroke="#94A3B8"
                  fontSize={11}
                  tickLine={false}
                  width={85}
                />
                <Tooltip
                  contentStyle={customTooltipStyle}
                  formatter={(val: any, name: any) => [
                    name === 'revenue' ? `$${Number(val).toLocaleString()}` : `$${Number(val).toLocaleString()}`,
                    name === 'revenue' ? 'Revenue' : 'Profit',
                  ]}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                <Bar dataKey="revenue" name="Revenue" fill="#6366F1" radius={[0, 4, 4, 0]} />
                <Bar dataKey="profit" name="Profit" fill="#38BDF8" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Regional Performance Comparison */}
        <div className="bg-[#1E293B]/80 border border-slate-700/80 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-semibold text-base flex items-center gap-2">
                <Activity className="w-4 h-4 text-sky-400" />
                Territory Performance
              </h3>
              <p className="text-xs text-slate-400">Global sales footprint, margins, and order volume</p>
            </div>
          </div>

          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={regionalData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="region" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis
                  stroke="#94A3B8"
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(val) => `$${(val / 1000).toFixed(0)}k`}
                />
                <Tooltip
                  contentStyle={customTooltipStyle}
                  formatter={(val: any, name: any) => [
                    name === 'revenue' ? `$${Number(val).toLocaleString()}` : `$${Number(val).toLocaleString()}`,
                    name === 'revenue' ? 'Revenue' : 'Profit',
                  ]}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                <Bar dataKey="revenue" name="Revenue" fill="#22C55E" radius={[6, 6, 0, 0]} />
                <Bar dataKey="profit" name="Profit" fill="#38BDF8" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
