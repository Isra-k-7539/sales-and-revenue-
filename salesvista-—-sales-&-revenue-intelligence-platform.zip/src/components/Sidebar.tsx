import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  TrendingUp,
  Package,
  Globe,
  Layers,
  Database,
  ShieldCheck,
  FileSpreadsheet,
  Settings,
  ChevronRight,
} from 'lucide-react';

export type NavTab =
  | 'overview'
  | 'revenue'
  | 'products'
  | 'regional'
  | 'topology3d'
  | 'data-management'
  | 'audit-logs';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  datasetName: string;
  totalRows: number;
  onOpenUpload: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  datasetName,
  totalRows,
  onOpenUpload,
}) => {
  const { user, userProfile, role, switchDemoRole } = useAuth();

  const navItems = [
    { id: 'overview' as NavTab, label: 'Overview', icon: LayoutDashboard },
    { id: 'revenue' as NavTab, label: 'Revenue Trends', icon: TrendingUp },
    { id: 'products' as NavTab, label: 'Product Analytics', icon: Package },
    { id: 'regional' as NavTab, label: 'Regional Analysis', icon: Globe },
    { id: 'topology3d' as NavTab, label: '3D Revenue Topology', icon: Layers, badge: 'WebGL' },
    { id: 'data-management' as NavTab, label: 'Data Management', icon: Database },
    { id: 'audit-logs' as NavTab, label: 'Audit & Compliance', icon: ShieldCheck },
  ];

  return (
    <aside className="w-64 bg-[#111827] border-r border-slate-800 flex flex-col justify-between shrink-0 h-screen sticky top-0 select-none">
      {/* Brand Header */}
      <div>
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-sky-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-white text-base tracking-tight flex items-center gap-1.5">
                SalesVista
              </h1>
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">
                Revenue Intelligence
              </p>
            </div>
          </div>
        </div>

        {/* Dataset Status Banner */}
        <div className="p-3 mx-3 my-3 bg-slate-900/80 border border-slate-800 rounded-xl">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="flex items-center gap-1 text-[11px] font-semibold text-indigo-400">
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Active Dataset
            </span>
            <span className="text-[10px] font-mono bg-indigo-950 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-800/40">
              {totalRows} rows
            </span>
          </div>
          <p className="text-xs font-medium text-white truncate mb-2">{datasetName}</p>
          <button
            onClick={onOpenUpload}
            className="w-full py-1 text-[11px] font-semibold text-center rounded-lg bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-600/30 transition-colors cursor-pointer"
          >
            Switch / Upload Data
          </button>
        </div>

        {/* Nav Links */}
        <nav className="px-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20 font-semibold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span
                    className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded ${
                      isActive ? 'bg-indigo-800 text-white' : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* RBAC Role & User Profile Bottom Card */}
      <div className="p-4 border-t border-slate-800 bg-[#0B1120]/60">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
            Access Role
          </span>
          <select
            value={role}
            onChange={(e) => switchDemoRole(e.target.value as any)}
            className="bg-slate-800 border border-slate-700 text-indigo-300 text-[11px] rounded-md px-1.5 py-0.5 font-medium focus:outline-none"
            title="Switch RBAC role"
          >
            <option value="admin">Admin</option>
            <option value="manager">Manager</option>
            <option value="analyst">Analyst</option>
            <option value="viewer">Viewer</option>
          </select>
        </div>

        <div className="flex items-center gap-2.5 pt-1">
          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs text-white uppercase overflow-hidden">
            {user?.photoURL ? (
              <img src={user.photoURL} alt="Avatar" className="w-full h-full object-cover" />
            ) : (
              <span>{user?.email ? user.email.charAt(0) : 'U'}</span>
            )}
          </div>
          <div className="truncate">
            <p className="text-xs font-semibold text-white truncate">
              {user?.displayName || (user?.email ? user.email.split('@')[0] : 'Demo User')}
            </p>
            <p className="text-[10px] text-slate-400 truncate">
              {user?.email || 'Logged in via Firebase'}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
};
