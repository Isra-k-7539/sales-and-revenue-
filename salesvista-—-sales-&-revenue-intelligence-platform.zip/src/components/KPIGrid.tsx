import React from 'react';
import { DashboardKPIs } from '../types/dashboard';
import { DollarSign, TrendingUp, ShoppingBag, Percent, ShoppingCart, Box, ArrowUpRight } from 'lucide-react';

interface KPIGridProps {
  kpis: DashboardKPIs;
}

export const KPIGrid: React.FC<KPIGridProps> = ({ kpis }) => {
  const cards = [
    {
      title: 'Total Revenue',
      value: `$${kpis.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`,
      delta: '+16.4%',
      deltaType: 'positive',
      icon: DollarSign,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10 border-emerald-500/20',
      subtitle: 'Gross billings across all channels',
    },
    {
      title: 'Total Profit',
      value: `$${kpis.totalProfit.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`,
      delta: '+19.2%',
      deltaType: 'positive',
      icon: TrendingUp,
      color: 'text-sky-400',
      bgColor: 'bg-sky-500/10 border-sky-500/20',
      subtitle: 'Net post-fulfillment earnings',
    },
    {
      title: 'Total Sales (Orders)',
      value: kpis.totalOrders.toLocaleString(),
      delta: '+8.7%',
      deltaType: 'positive',
      icon: ShoppingBag,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/10 border-indigo-500/20',
      subtitle: 'Executed customer transactions',
    },
    {
      title: 'Profit Margin',
      value: `${kpis.profitMargin}%`,
      delta: '+2.1% pts',
      deltaType: 'positive',
      icon: Percent,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10 border-purple-500/20',
      subtitle: 'Net margin ratio vs revenue',
    },
    {
      title: 'Average Order Value',
      value: `$${kpis.averageOrderValue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`,
      delta: '+$340',
      deltaType: 'positive',
      icon: ShoppingCart,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10 border-amber-500/20',
      subtitle: 'Yield per customer checkout',
    },
    {
      title: 'Total Units Sold',
      value: kpis.totalUnitsSold.toLocaleString(),
      delta: '+12.5%',
      deltaType: 'positive',
      icon: Box,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/10 border-pink-500/20',
      subtitle: 'Deployed software seats & packages',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            className="bg-[#1E293B]/80 hover:bg-[#1E293B] border border-slate-700/60 rounded-2xl p-4 transition-all duration-200 hover:border-slate-600 hover:shadow-lg flex flex-col justify-between group"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{card.title}</span>
              <div className={`p-2 rounded-xl border ${card.bgColor}`}>
                <Icon className={`w-4 h-4 ${card.color}`} />
              </div>
            </div>

            <div>
              <div className="text-2xl font-bold text-white tracking-tight group-hover:scale-[1.02] transition-transform origin-left">
                {card.value}
              </div>
              <div className="flex items-center gap-1.5 mt-2">
                <span className="inline-flex items-center text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-1.5 py-0.5 rounded">
                  <ArrowUpRight className="w-3 h-3 mr-0.5" />
                  {card.delta}
                </span>
                <span className="text-[11px] text-slate-400 truncate">{card.subtitle}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
