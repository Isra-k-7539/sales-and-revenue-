import React from 'react';
import { FilterState } from '../types/dashboard';
import { Calendar, Filter, RotateCcw, Search, Tag, Globe, Layers } from 'lucide-react';

interface FilterBarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  availableRegions: string[];
  availableCategories: string[];
  availableChannels: string[];
  onReset: () => void;
  filteredCount: number;
  totalCount: number;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  setFilters,
  availableRegions,
  availableCategories,
  availableChannels,
  onReset,
  filteredCount,
  totalCount,
}) => {
  const toggleRegion = (region: string) => {
    setFilters((prev) => {
      const exists = prev.selectedRegions.includes(region);
      return {
        ...prev,
        selectedRegions: exists
          ? prev.selectedRegions.filter((r) => r !== region)
          : [...prev.selectedRegions, region],
      };
    });
  };

  const toggleCategory = (category: string) => {
    setFilters((prev) => {
      const exists = prev.selectedCategories.includes(category);
      return {
        ...prev,
        selectedCategories: exists
          ? prev.selectedCategories.filter((c) => c !== category)
          : [...prev.selectedCategories, category],
      };
    });
  };

  const setDatePreset = (preset: 'all' | 'q1q2' | 'q3q4' | 'recent') => {
    if (preset === 'all') {
      setFilters((prev) => ({ ...prev, startDate: '', endDate: '' }));
    } else if (preset === 'q1q2') {
      setFilters((prev) => ({ ...prev, startDate: '2024-01-01', endDate: '2024-06-30' }));
    } else if (preset === 'q3q4') {
      setFilters((prev) => ({ ...prev, startDate: '2024-07-01', endDate: '2024-12-31' }));
    } else if (preset === 'recent') {
      setFilters((prev) => ({ ...prev, startDate: '2024-09-01', endDate: '2024-12-31' }));
    }
  };

  const hasActiveFilters =
    filters.startDate ||
    filters.endDate ||
    filters.selectedRegions.length > 0 ||
    filters.selectedCategories.length > 0 ||
    filters.selectedChannels.length > 0 ||
    filters.searchTerm;

  return (
    <div className="bg-[#1E293B]/90 border border-slate-700/80 rounded-2xl p-4 shadow-xl space-y-3.5">
      {/* Top Filter Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Search input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Search products, clients, or order IDs..."
            value={filters.searchTerm}
            onChange={(e) => setFilters((prev) => ({ ...prev, searchTerm: e.target.value }))}
            className="w-full bg-[#111827] border border-slate-700 text-white placeholder-slate-400 text-xs rounded-xl pl-9 pr-3.5 py-2 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
          />
        </div>

        {/* Date presets */}
        <div className="flex items-center gap-1.5 bg-[#111827] border border-slate-700 p-1 rounded-xl">
          <Calendar className="w-3.5 h-3.5 text-slate-400 ml-2 mr-1" />
          <button
            onClick={() => setDatePreset('all')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
              !filters.startDate && !filters.endDate ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            All Dates
          </button>
          <button
            onClick={() => setDatePreset('q1q2')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
              filters.startDate === '2024-01-01' && filters.endDate === '2024-06-30'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            H1
          </button>
          <button
            onClick={() => setDatePreset('q3q4')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
              filters.startDate === '2024-07-01' && filters.endDate === '2024-12-31'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            H2
          </button>
          <button
            onClick={() => setDatePreset('recent')}
            className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
              filters.startDate === '2024-09-01' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Q4 Focus
          </button>
        </div>

        {/* Custom date range */}
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={filters.startDate}
            onChange={(e) => setFilters((prev) => ({ ...prev, startDate: e.target.value }))}
            className="bg-[#111827] border border-slate-700 text-slate-300 text-xs rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-indigo-500"
            title="Start date"
          />
          <span className="text-slate-500 text-xs">to</span>
          <input
            type="date"
            value={filters.endDate}
            onChange={(e) => setFilters((prev) => ({ ...prev, endDate: e.target.value }))}
            className="bg-[#111827] border border-slate-700 text-slate-300 text-xs rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-indigo-500"
            title="End date"
          />
        </div>

        {/* Reset button */}
        {hasActiveFilters && (
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-500/10 border border-rose-500/30 text-rose-300 hover:bg-rose-500/20 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset ({filteredCount} / {totalCount})
          </button>
        )}
      </div>

      {/* Slicers Row: Region & Category Pills */}
      <div className="pt-2 border-t border-slate-700/60 flex flex-wrap items-center gap-4 text-xs">
        {/* Regions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 flex items-center gap-1 mr-1 font-medium">
            <Globe className="w-3.5 h-3.5 text-indigo-400" /> Region:
          </span>
          {availableRegions.map((region) => {
            const isSelected = filters.selectedRegions.includes(region);
            return (
              <button
                key={region}
                onClick={() => toggleRegion(region)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                    : 'bg-[#111827] border-slate-700 text-slate-300 hover:border-slate-600 hover:text-white'
                }`}
              >
                {region}
              </button>
            );
          })}
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-slate-400 flex items-center gap-1 mr-1 font-medium">
            <Layers className="w-3.5 h-3.5 text-sky-400" /> Category:
          </span>
          {availableCategories.map((cat) => {
            const isSelected = filters.selectedCategories.includes(cat);
            return (
              <button
                key={cat}
                onClick={() => toggleCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-sky-600 border-sky-500 text-white shadow-sm'
                    : 'bg-[#111827] border-slate-700 text-slate-300 hover:border-slate-600 hover:text-white'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
