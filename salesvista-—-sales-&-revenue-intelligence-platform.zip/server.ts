import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // Shared Gemini client with telemetry header
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // AI Insights generation endpoint
  app.post('/api/ai/insights', async (req, res) => {
    try {
      const { summaryData, question } = req.body;
      if (!summaryData) {
        return res.status(400).json({ error: 'Missing summaryData in request body' });
      }

      const prompt = `You are the Principal Revenue Operations & Financial Intelligence Analyst for SalesVista.
Analyze this business performance dataset summary:
${JSON.stringify(summaryData, null, 2)}

${
  question
    ? `The user is specifically asking: "${question}". Answer clearly with precise metrics, drivers, and recommendations.`
    : `Provide an Executive Revenue Intelligence Briefing:
1. **Executive Snapshot**: Overall health, revenue scale, margin efficiency, and trajectory.
2. **Top Growth Engines**: Which categories, regions, or products generate maximum yield.
3. **Margin Risks & Anomalies**: Leakages, discount overheads, low-margin clusters, or risk flags.
4. **Actionable Recommendations**: 3 high-impact, prioritized levers to boost revenue and profit margin immediately.`
}

Return a concise, authoritative executive report formatted in clean Markdown with bold numbers, formatted currency, and bulleted takeaways.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      res.json({ insights: response.text });
    } catch (error: any) {
      console.error('Gemini API Error:', error);
      res.status(500).json({
        error: error?.message || 'Failed to generate AI revenue insights',
      });
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SalesVista server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
